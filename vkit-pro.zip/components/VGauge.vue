<template>
  <div class="vk-gauge" :style="{ width: px + 'px' }">
    <svg viewBox="0 0 100 60">
      <path class="tr" d="M 8 55 A 42 42 0 0 1 92 55" fill="none" stroke-linecap="round" :stroke-width="stroke"></path>
      <path class="fg" d="M 8 55 A 42 42 0 0 1 92 55" fill="none" stroke-linecap="round" :stroke-width="stroke"
        :style="{ stroke: activeColor }" :stroke-dasharray="len" :stroke-dashoffset="len * (1 - pct)"></path>
    </svg>
    <div class="mid">
      <span class="v">{{ value }}<em>{{ suffix }}</em></span>
      <span v-if="label" class="l">{{ label }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'VGauge',
  props: {
    value: { type: Number, default: 0 },
    max: { type: Number, default: 100 },
    label: String,
    suffix: { type: String, default: '%' },
    size: { type: String, default: 'medium' },
    stroke: { type: Number, default: 9 },
    thresholds: { type: Array, default: () => [] }   // [{upto, color}] color zones, e.g. [{upto:60,color:'#059669'},{upto:85,color:'#d97706'},{upto:100,color:'#dc2626'}]
  },
  computed: {
    px() { return { small: 110, medium: 160, large: 220 }[this.size] || 160 },
    pct() { return Math.min(1, Math.max(0, this.value / this.max)) },
    len() { return Math.PI * 42 },
    activeColor() {
      if (!this.thresholds.length) return 'var(--vk-accent)'
      const pctVal = (this.value / this.max) * 100
      const hit = this.thresholds.find(t => pctVal <= t.upto)
      return hit ? hit.color : this.thresholds[this.thresholds.length - 1].color
    }
  }
};
</script>

<style>
.vk-gauge{position:relative;display:inline-block}
.vk-gauge .tr{stroke:var(--vk-sunken)}
.vk-gauge .fg{stroke:var(--vk-accent);transition:stroke-dashoffset .5s ease,stroke .3s}
.vk-gauge .mid{position:absolute;left:0;right:0;bottom:8%;text-align:center}
.vk-gauge .v{font-size:1.55em;font-weight:800;display:block;line-height:1}
.vk-gauge .v em{font-style:normal;font-size:.55em;color:var(--vk-text-3)}
.vk-gauge .l{font-size:10.5px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--vk-text-3)}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
