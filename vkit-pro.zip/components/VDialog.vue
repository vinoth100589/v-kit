<template>
  <teleport to="body">
    <div v-if="modelValue" class="vk-dlg-mask" @click.self="closeOnBodyClick && !persistent && close()">
      <div class="vk-dlg" :class="'vk-dlg--' + size" :style="{ maxWidth: sizeWidth, top: dy + 'px', left: dx === null ? '' : dx + 'px', position: dx === null ? 'relative' : 'absolute' }">
        <div class="hd" :class="{ grab: draggable }" @mousedown="draggable && startDrag($event)">
          <span>{{ title }}</span>
          <button v-if="closeButton && !persistent" aria-label="Close" @click="close">✕</button>
        </div>
        <div class="bd"><slot>{{ content }}</slot></div>
        <div v-if="buttons.length || $slots.footer" class="ft" :style="{ justifyContent: buttonsAlignment === 'left' ? 'flex-start' : 'flex-end' }">
          <slot name="footer">
            <v-button v-for="(b, i) in buttons" :key="i" size="small"
              :appearance="b.appearance || 'secondary'" :text="b.text"
              @click="$emit('buttonclick', b); b.close !== false && close()"></v-button>
          </slot>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VDialog',
  components: { VButton },
  props: {
    modelValue: Boolean,
    title: { type: String, default: 'Dialog' },
    content: String,
    size: { type: String, default: 'medium' },   // small | medium | large | full — overridden by explicit width
    width: String,
    buttons: { type: Array, default: () => [] },   // [{text, appearance, close}]
    buttonsAlignment: { type: String, default: 'right' },
    closeButton: { type: Boolean, default: true },
    closeOnBodyClick: { type: Boolean, default: true },
    closeOnEscKey: { type: Boolean, default: true },
    persistent: Boolean,   // ignores outside click, Esc key and hides the close button
    draggable: Boolean
  },
  emits: ['update:modelValue', 'open', 'close', 'buttonclick'],
  data() { return { dx: null, dy: 0 } },
  computed: {
    sizeWidth() {
      if (this.width) return this.width
      return { small: '380px', medium: '520px', large: '760px', full: '96vw' }[this.size] || '520px'
    }
  },
  watch: {
    modelValue(v) { this.$emit(v ? 'open' : 'close'); if (v) { this.dx = null; this.dy = 0 } }
  },
  mounted() {
    this.__esc = (e) => { if (e.key === 'Escape' && this.closeOnEscKey && !this.persistent && this.modelValue) this.close() }
    document.addEventListener('keydown', this.__esc)
  },
  unmounted() { document.removeEventListener('keydown', this.__esc) },
  methods: {
    open() { this.$emit('update:modelValue', true) },
    close() { this.$emit('update:modelValue', false) },
    startDrag(e) {
      const el = e.currentTarget.parentElement, r = el.getBoundingClientRect()
      const ox = e.clientX - r.left, oy = e.clientY - r.top
      const mv = (ev) => { this.dx = ev.clientX - ox; this.dy = ev.clientY - oy }
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up) }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up)
    }
  }
};
</script>

<style>
.vk-dlg-mask{position:fixed;inset:0;background:color-mix(in srgb,var(--vk-shell) 55%,transparent);backdrop-filter:blur(2px);z-index:950;display:flex;align-items:flex-start;justify-content:center;padding:80px 18px}
.vk-dlg{background:var(--vk-raised);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);width:100%;display:flex;flex-direction:column;max-height:78vh;animation:vk-pop-in .18s ease}
.vk-dlg--full{max-height:94vh}
.vk-dlg .hd{display:flex;align-items:center;justify-content:space-between;padding:16px 22px;font-weight:700;font-size:15px;border-bottom:1px solid var(--vk-line)}
.vk-dlg .hd.grab{cursor:grab}
.vk-dlg .hd button{border:none;background:var(--vk-sunken);width:28px;height:28px;border-radius:8px;font-size:13px;cursor:pointer;color:var(--vk-text-2)}
.vk-dlg .bd{padding:20px 22px;overflow-y:auto}
.vk-dlg .ft{padding:14px 22px;border-top:1px solid var(--vk-line);display:flex;gap:9px}

/* --- V-Kit shared styles (tokens + 4 themes + pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
