<template>
  <div v-if="visible" class="vk-pop vk-cpick" :class="{ 'vk-pop--under': true, 'vk-cpick--adv': showAdvanced }">
    <template v-if="!showAdvanced">
      <div class="grid" role="group" aria-label="Color swatches" @keydown="onGridKeydown">
        <button v-for="(c, i) in palette" :key="c" ref="swatches" class="sw" :style="{ background: c }"
          :tabindex="i === 0 ? 0 : -1" :class="{ on: c.toLowerCase() === (modelValue || '').toLowerCase() }"
          :disabled="disabled" :aria-label="c" @click="pick(c)"></button>
      </div>
      <div v-if="usedColors.length" class="used">
        <div class="cap">Recently used</div>
        <button v-for="c in usedColors" :key="'u' + c" class="sw" :style="{ background: c }" :disabled="disabled" :aria-label="c" @click="pick(c)"></button>
      </div>
      <div class="foot">
        <input class="vk-input vk-input--sm" style="width:110px;font-family:var(--vk-mono)" :value="modelValue" :disabled="disabled"
          placeholder="#hex" @change="pick($event.target.value)">
        <v-button v-if="advancedPicker" appearance="link" size="small" :text="advancedPickerButtonLabel" @click="showAdvanced = true"></v-button>
      </div>
    </template>
    <template v-else>
      <div class="sat" :style="{ background: satBg }" @mousedown="dragSat">
        <div class="cursor" :style="{ left: s + '%', top: (100 - l2) + '%' }"></div>
      </div>
      <input class="hue" type="range" min="0" max="360" :value="h" @input="h = Number($event.target.value); emitAdv()">
      <input v-if="showAlpha" class="hue alpha" type="range" min="0" max="100" :value="a" @input="a = Number($event.target.value); emitAdv()">
      <div class="fmt-tabs">
        <button v-for="f in ['hex', 'rgb', 'hsl']" :key="f" type="button" :class="{ on: format === f }" @click="format = f">{{ f.toUpperCase() }}</button>
      </div>
      <div class="row">
        <span class="prev" :style="{ background: previewColor }"></span>
        <input class="vk-input vk-input--sm" style="font-family:var(--vk-mono);flex:1" :value="formattedValue" @change="fromInput($event.target.value)">
        <button v-if="hasEyeDropper" type="button" class="vk-cp-tool" aria-label="Pick color from screen" title="Eyedropper" @click="useEyeDropper">◎</button>
        <button type="button" class="vk-cp-tool" aria-label="Copy value" title="Copy" @click="copyValue">{{ copied ? '✓' : '⧉' }}</button>
      </div>
      <div class="tools">
        <div class="tool-tabs" role="tablist" aria-label="Color tools">
          <button type="button" role="tab" :aria-selected="toolPanel === 'harmony'" :class="{ on: toolPanel === 'harmony' }"
            @click="toolPanel = toolPanel === 'harmony' ? null : 'harmony'">Harmony</button>
          <button type="button" role="tab" :aria-selected="toolPanel === 'shades'" :class="{ on: toolPanel === 'shades' }"
            @click="toolPanel = toolPanel === 'shades' ? null : 'shades'">Shades</button>
          <button type="button" role="tab" :aria-selected="toolPanel === 'contrast'" :class="{ on: toolPanel === 'contrast' }"
            @click="toolPanel = toolPanel === 'contrast' ? null : 'contrast'">Contrast</button>
        </div>
        <div v-if="toolPanel === 'harmony'" class="panel">
          <div v-for="scheme in harmonySchemes" :key="scheme.name" class="hrow">
            <span class="hlbl">{{ scheme.name }}</span>
            <span class="hswatches">
              <button v-for="c in scheme.colors" :key="c" type="button" class="sw" :style="{ background: c }" :aria-label="c" @click="fromInput(c)"></button>
            </span>
          </div>
        </div>
        <div v-if="toolPanel === 'shades'" class="panel">
          <div class="hswatches" style="flex-wrap:nowrap">
            <button v-for="c in shades" :key="c" type="button" class="sw wide" :style="{ background: c }" :aria-label="c" @click="fromInput(c)"></button>
          </div>
        </div>
        <div v-if="toolPanel === 'contrast'" class="panel">
          <div class="crow">
            <span>Against</span>
            <input class="vk-input vk-input--sm" style="font-family:var(--vk-mono);width:90px" :value="contrastBg" @change="contrastBg = $event.target.value">
            <button type="button" class="mini" @click="contrastBg = '#ffffff'">White</button>
            <button type="button" class="mini" @click="contrastBg = '#000000'">Black</button>
          </div>
          <div class="cresult">
            <span class="ratio" :style="{ background: contrastBg, color: hex }">Aa</span>
            <span class="ratioval">{{ contrastRatio.toFixed(2) }}:1</span>
            <span class="badge" :class="{ pass: contrastRatio >= 4.5 }">AA text {{ contrastRatio >= 4.5 ? '✓' : '✗' }}</span>
            <span class="badge" :class="{ pass: contrastRatio >= 3 }">AA large {{ contrastRatio >= 3 ? '✓' : '✗' }}</span>
            <span class="badge" :class="{ pass: contrastRatio >= 7 }">AAA text {{ contrastRatio >= 7 ? '✓' : '✗' }}</span>
          </div>
        </div>
      </div>

      <div class="adv-foot">
        <v-button appearance="secondary" size="small" text="Back" @click="showAdvanced = false"></v-button>
        <v-button appearance="primary" size="small" :text="advancedApplyLabel" @click="applyAdvanced"></v-button>
      </div>
    </template>
  </div>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VColorPicker',
  components: { VButton },
  props: {
    modelValue: String,
    visible: Boolean,
    colors: { type: Array, default: () => [] },
    advancedPicker: Boolean,
    advancedPickerButtonLabel: { type: String, default: 'More…' },
    advancedApplyLabel: { type: String, default: 'Apply' },
    showAlpha: Boolean,   // adds an opacity slider in advanced mode
    closeOnSelect: { type: Boolean, default: true },
    disabled: Boolean
  },
  emits: ['update:modelValue', 'change', 'update:visible', 'advanced'],
  data() {
    return { usedColors: [], showAdvanced: false, h: 262, s: 76, l2: 58, a: 100, format: 'hex', copied: false, toolPanel: null, contrastBg: '#ffffff' }
  },
  computed: {
    palette() {
      if (this.colors.length) return this.colors
      return ['#0f172a','#475569','#94a3b8','#e2e8f0','#7c3aed','#a78bfa','#2563eb','#38bdf8',
              '#06b6d4','#0d9488','#059669','#84cc16','#eab308','#f59e0b','#ea580c','#dc2626',
              '#e11d48','#db2777','#c026d3','#ffffff']
    },
    hasEyeDropper() { return typeof window !== 'undefined' && !!window.EyeDropper },
    satBg() { return 'linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,hsl(' + this.h + ',100%,50%))' },
    hex() { return this.hslToHex(this.h, this.s, this.l2 / 2 + 20) },
    rgbObj() {
      const hex = this.hex
      return { r: parseInt(hex.slice(1, 3), 16), g: parseInt(hex.slice(3, 5), 16), b: parseInt(hex.slice(5, 7), 16) }
    },
    rgba() { const c = this.rgbObj; return 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + (this.a / 100).toFixed(2) + ')' },
    hsl() { return 'hsl(' + this.h + ',' + Math.round(this.s) + '%,' + Math.round(this.l2 / 2 + 20) + '%)' },
    previewColor() { return this.showAlpha ? this.rgba : this.hex },
    formattedValue() {
      if (this.format === 'rgb') return this.showAlpha ? this.rgba : 'rgb(' + this.rgbObj.r + ',' + this.rgbObj.g + ',' + this.rgbObj.b + ')'
      if (this.format === 'hsl') return this.hsl
      return this.hex
    },
    harmonySchemes() {
      const l = this.l2 / 2 + 20
      const at = (dh) => this.hslToHex((this.h + dh + 360) % 360, this.s, l)
      return [
        { name: 'Complementary', colors: [this.hex, at(180)] },
        { name: 'Analogous', colors: [at(-30), this.hex, at(30)] },
        { name: 'Triadic', colors: [this.hex, at(120), at(240)] },
        { name: 'Split-comp.', colors: [this.hex, at(150), at(210)] },
        { name: 'Tetradic', colors: [this.hex, at(90), at(180), at(270)] }
      ]
    },
    shades() {
      return [12, 24, 36, 48, 60, 72, 84].map(l => this.hslToHex(this.h, this.s, l))
    },
    contrastRatio() {
      const l1 = this.relLuminance(this.hex), l2v = this.relLuminance(this.contrastBg)
      const lighter = Math.max(l1, l2v), darker = Math.min(l1, l2v)
      return (lighter + 0.05) / (darker + 0.05)
    }
  },
  watch: {
    visible(v) { if (v) { this.showAdvanced = false; this.toolPanel = null; this.syncFromModelValue() } }
  },
  methods: {
    pick(c) {
      if (!c || this.disabled) return
      if (!this.usedColors.includes(c)) this.usedColors = [c, ...this.usedColors].slice(0, 8)
      this.$emit('update:modelValue', c); this.$emit('change', c)
      if (this.closeOnSelect) this.$emit('update:visible', false)
    },
    open() { this.$emit('update:visible', true) },
    close() { this.$emit('update:visible', false) },
    onGridKeydown(e) {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return
      const els = this.$refs.swatches || []
      const cur = els.findIndex(el => el === document.activeElement)
      if (cur === -1) return
      e.preventDefault()
      const cols = 8
      let next = cur
      if (e.key === 'ArrowLeft') next = cur - 1
      else if (e.key === 'ArrowRight') next = cur + 1
      else if (e.key === 'ArrowUp') next = cur - cols
      else if (e.key === 'ArrowDown') next = cur + cols
      if (next < 0) next = 0
      if (next >= els.length) next = els.length - 1
      els[next] && els[next].focus()
    },
    syncFromModelValue(override) {
      const v = (override !== undefined ? override : (this.modelValue || '')).trim()
      const hex6 = /^#([0-9a-f]{6})$/i
      let r, g, b
      if (hex6.test(v)) {
        r = parseInt(v.slice(1, 3), 16); g = parseInt(v.slice(3, 5), 16); b = parseInt(v.slice(5, 7), 16)
      } else {
        const m = v.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)/i)
        if (m) { r = +m[1]; g = +m[2]; b = +m[3]; if (m[4] !== undefined) this.a = Math.round(parseFloat(m[4]) * 100) }
      }
      if (r === undefined) return
      const { h, s, l } = this.rgbToHsl(r, g, b)
      this.h = h; this.s = s; this.l2 = Math.min(100, Math.max(0, (l - 20) * 2))
    },
    rgbToHsl(r, g, b) {
      r /= 255; g /= 255; b /= 255
      const max = Math.max(r, g, b), min = Math.min(r, g, b)
      let h = 0, s = 0; const l = (max + min) / 2
      if (max !== min) {
        const d = max - min
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
        if (max === r) h = (g - b) / d + (g < b ? 6 : 0)
        else if (max === g) h = (b - r) / d + 2
        else h = (r - g) / d + 4
        h *= 60
      }
      return { h: Math.round(h), s: Math.round(s * 100), l: Math.round(l * 100) }
    },
    hslToHex(h, s, l) {
      s /= 100; l /= 100
      const k = n => (n + h / 30) % 12
      const a = s * Math.min(l, 1 - l)
      const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))
      const to = x => Math.round(255 * x).toString(16).padStart(2, '0')
      return '#' + to(f(0)) + to(f(8)) + to(f(4))
    },
    relLuminance(hex) {
      const c = (hex || '#000000').replace('#', '')
      const r = parseInt(c.slice(0, 2), 16) / 255, g = parseInt(c.slice(2, 4), 16) / 255, b = parseInt(c.slice(4, 6), 16) / 255
      const f = x => (x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4))
      return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
    },
    fromInput(v) {
      if (/^#[0-9a-f]{6}$/i.test(v)) {
        this.$emit('update:modelValue', v); this.$emit('change', v); this.syncFromModelValue(v)
      } else if (/^rgba?\(/i.test(v) || /^hsl\(/i.test(v)) {
        this.$emit('update:modelValue', v); this.$emit('change', v)
      }
    },
    dragSat(e) {
      const el = e.currentTarget
      const mv = (ev) => {
        const r = el.getBoundingClientRect()
        this.s = Math.min(100, Math.max(0, ((ev.clientX - r.left) / r.width) * 100))
        this.l2 = Math.min(100, Math.max(0, 100 - ((ev.clientY - r.top) / r.height) * 100))
        this.emitAdv()
      }
      mv(e)
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up) }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up)
    },
    emitAdv() { this.$emit('update:modelValue', this.previewColor); this.$emit('change', this.previewColor) },
    applyAdvanced() {
      this.emitAdv()
      if (!this.usedColors.includes(this.previewColor)) this.usedColors = [this.previewColor, ...this.usedColors].slice(0, 8)
      this.showAdvanced = false
      if (this.closeOnSelect) this.$emit('update:visible', false)
    },
    async useEyeDropper() {
      if (!this.hasEyeDropper) return
      try {
        const res = await new window.EyeDropper().open()
        if (res && res.sRGBHex) this.fromInput(res.sRGBHex)
      } catch (e) { /* user cancelled */ }
    },
    async copyValue() {
      try {
        await navigator.clipboard.writeText(this.formattedValue)
        this.copied = true; setTimeout(() => { this.copied = false }, 1200)
      } catch (e) { /* clipboard unavailable */ }
    }
  }
};
</script>

<style>
.vk-cpick{padding:13px;width:236px}
.vk-cpick--adv{width:270px}
.vk-cpick .grid{display:grid;grid-template-columns:repeat(8,1fr);gap:6px}
.vk-cpick .sw{width:22px;height:22px;border-radius:7px;border:1px solid var(--vk-line);cursor:pointer;transition:.12s;padding:0}
.vk-cpick .sw:hover{transform:scale(1.18)}
.vk-cpick .sw.on{outline:2px solid var(--vk-accent);outline-offset:1.5px}
.vk-cpick .sw:disabled{opacity:.4;cursor:not-allowed;transform:none}
.vk-cpick .sw:focus-visible{outline:2px solid var(--vk-accent);outline-offset:1.5px}
.vk-cpick .used{margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.vk-cpick .cap{width:100%;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--vk-text-3);margin-bottom:2px}
.vk-cpick .foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:11px;border-top:1px dashed var(--vk-line);padding-top:11px}
.vk-cpick .sat{height:130px;border-radius:var(--vk-radius-s);position:relative;cursor:crosshair;margin-bottom:11px}
.vk-cpick .cursor{position:absolute;width:14px;height:14px;border:2.5px solid #fff;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 0 4px rgba(0,0,0,.5);pointer-events:none}
.vk-cpick .hue{width:100%;appearance:none;height:11px;border-radius:999px;outline:none;cursor:pointer;background:linear-gradient(to right,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00);margin-bottom:11px}
.vk-cpick .hue.alpha{background:linear-gradient(to right,transparent,var(--vk-accent)),repeating-conic-gradient(#ccc 0 25%,#fff 0 50%) 50%/8px 8px}
.vk-cpick .hue::-webkit-slider-thumb{appearance:none;width:17px;height:17px;border-radius:50%;background:#fff;border:2px solid var(--vk-line-2);box-shadow:var(--vk-shadow)}
.vk-cpick .fmt-tabs{display:flex;gap:5px;margin-bottom:9px}
.vk-cpick .fmt-tabs button{flex:1;border:1.5px solid var(--vk-line-2);background:var(--vk-surface);color:var(--vk-text-2);border-radius:7px;font-size:11px;font-weight:700;padding:5px 0;cursor:pointer;font-family:inherit}
.vk-cpick .fmt-tabs button.on{background:var(--vk-grad);border-color:transparent;color:var(--vk-on-accent)}
.vk-cpick .row{display:flex;align-items:center;gap:7px}
.vk-cpick .prev{width:30px;height:30px;border-radius:9px;border:1px solid var(--vk-line);flex:none}
.vk-cp-tool{border:1.5px solid var(--vk-line-2);background:var(--vk-surface);color:var(--vk-text-2);width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:13px;flex:none}
.vk-cp-tool:hover{border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-cpick .adv-foot{display:flex;justify-content:flex-end;gap:8px;margin-top:11px;border-top:1px dashed var(--vk-line);padding-top:11px}
.vk-cpick .tools{margin-top:11px;border-top:1px dashed var(--vk-line);padding-top:10px}
.vk-cpick .tool-tabs{display:flex;gap:5px}
.vk-cpick .tool-tabs button{flex:1;border:1.5px solid var(--vk-line-2);background:var(--vk-surface);color:var(--vk-text-2);border-radius:7px;font-size:10.5px;font-weight:700;padding:5px 0;cursor:pointer;font-family:inherit}
.vk-cpick .tool-tabs button.on{background:var(--vk-accent-soft);border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-cpick .panel{margin-top:9px}
.vk-cpick .hrow{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}
.vk-cpick .hlbl{font-size:11px;color:var(--vk-text-3);font-weight:600;flex:none}
.vk-cpick .hswatches{display:flex;gap:5px;flex-wrap:wrap}
.vk-cpick .hswatches .sw{width:20px;height:20px;border-radius:6px;border:1px solid var(--vk-line);cursor:pointer;padding:0}
.vk-cpick .hswatches .sw:hover{transform:scale(1.15)}
.vk-cpick .hswatches .sw.wide{width:28px;height:26px;border-radius:5px}
.vk-cpick .crow{display:flex;align-items:center;gap:6px;margin-bottom:9px;font-size:11.5px;color:var(--vk-text-3)}
.vk-cpick .crow input{flex:none}
.vk-cpick .mini{border:1.5px solid var(--vk-line-2);background:var(--vk-surface);color:var(--vk-text-2);border-radius:6px;font-size:10.5px;font-weight:650;padding:4px 8px;cursor:pointer;font-family:inherit}
.vk-cpick .mini:hover{border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-cpick .cresult{display:flex;align-items:center;flex-wrap:wrap;gap:7px}
.vk-cpick .ratio{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;border:1px solid var(--vk-line)}
.vk-cpick .ratioval{font-family:var(--vk-mono);font-size:12.5px;font-weight:700;color:var(--vk-text)}
.vk-cpick .badge{font-size:10px;font-weight:700;padding:3px 7px;border-radius:999px;background:var(--vk-sunken);color:var(--vk-text-3)}
.vk-cpick .badge.pass{background:color-mix(in srgb,#16a34a 18%,transparent);color:#16a34a}

/* --- V-Kit shared styles (tokens + 4 themes + field, pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}

.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
