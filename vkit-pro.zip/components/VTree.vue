<template>
  <ul class="vk-tree" :role="nested ? 'group' : 'tree'" @keydown="!nested && onKeydown($event)">
    <li v-for="(n, i) in nodes" :key="i" role="treeitem" :aria-expanded="n.children && n.children.length ? isOpen(n) : null">
      <div class="nd" tabindex="0" :class="{ sel: selected === n.label }" :aria-selected="selected === n.label" @click="pick(n)">
        <span v-if="n.children && n.children.length" class="car" :class="{ open: isOpen(n) }"
          @click.stop="toggle(n)">▸</span>
        <span v-else class="car leaf">·</span>
        <input v-if="checkboxes" type="checkbox" tabindex="-1" :checked="checkedSet.includes(n.label)" @click.stop="toggleCheck(n)">
        <span v-if="n.icon">{{ n.icon }}</span>
        <span>{{ n.label }}</span>
        <span v-if="n.badge" class="bg">{{ n.badge }}</span>
      </div>
      <v-tree v-if="n.children && isOpen(n)" :nodes="n.children" :selected="selected" :checkboxes="checkboxes"
        :checked="checked" :nested="true" @select="$emit('select', $event)" @toggle="$emit('toggle', $event)"
        @update:checked="$emit('update:checked', $event)" style="padding-left:22px"></v-tree>
    </li>
  </ul>
</template>

<script>
export default {
  name: 'VTree',
  props: {
    nodes: { type: Array, default: () => [] },   // [{label, icon?, badge?, children?, expanded?}]
    selected: String,
    checkboxes: Boolean,   // multi-select mode with checkboxes instead of single click-select
    checked: { type: Array, default: () => [] },   // v-model:checked — labels of checked nodes
    nested: { type: Boolean, default: false }   // internal — true for recursively-rendered child levels
  },
  emits: ['select', 'toggle', 'update:checked'],
  data() { return { openSet: this.nodes.filter(n => n.expanded).map(n => n.label) } },
  computed: { checkedSet() { return this.checked } },
  methods: {
    isOpen(n) { return this.openSet.includes(n.label) },
    toggle(n) {
      const i = this.openSet.indexOf(n.label)
      i > -1 ? this.openSet.splice(i, 1) : this.openSet.push(n.label)
      this.$emit('toggle', n.label)
    },
    toggleCheck(n) {
      const at = this.checked.indexOf(n.label)
      const next = [...this.checked]
      at > -1 ? next.splice(at, 1) : next.push(n.label)
      this.$emit('update:checked', next)
    },
    pick(n) {
      if (n.children && n.children.length) this.toggle(n)
      else if (!this.checkboxes) this.$emit('select', n.label)
    },
    onKeydown(e) {
      if (!['ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowLeft', 'Enter', ' '].includes(e.key)) return
      const nd = e.target.closest ? e.target.closest('.nd') : null
      if (!nd) return
      const all = [...this.$el.querySelectorAll('.nd')]
      const cur = all.indexOf(nd)
      if (e.key === 'ArrowDown') { e.preventDefault(); (all[cur + 1] || all[0]).focus() }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (all[cur - 1] || all[all.length - 1]).focus() }
      else if (e.key === 'ArrowRight') {
        e.preventDefault()
        const car = nd.querySelector(':scope > .car:not(.leaf)')
        if (car) car.click(); else (all[cur + 1] || nd).focus()
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault()
        const car = nd.querySelector(':scope > .car.open')
        if (car) car.click()
        else {
          const parentLi = nd.closest('li')?.parentElement?.closest('li')
          const parentNd = parentLi?.querySelector(':scope > .nd')
          if (parentNd) parentNd.focus()
        }
      } else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); nd.click() }
    }
  }
};
</script>

<style>
.vk-tree{list-style:none;margin:0;padding:0;font-size:13px;min-width:230px}
.vk-tree .nd{display:flex;align-items:center;gap:7px;padding:6.5px 9px;border-radius:8px;cursor:pointer}
.vk-tree .nd:hover{background:var(--vk-sunken)}
.vk-tree .nd:focus-visible{outline:2px solid var(--vk-accent);outline-offset:-2px}
.vk-tree .nd.sel{background:var(--vk-accent-soft);color:var(--vk-accent);font-weight:650}
.vk-tree .car{width:13px;font-size:10px;color:var(--vk-text-3);transition:.15s;text-align:center}
.vk-tree .car.open{transform:rotate(90deg)}
.vk-tree .car.leaf{opacity:.5}
.vk-tree .nd input[type=checkbox]{accent-color:var(--vk-accent);margin:0}
.vk-tree .bg{margin-left:auto;background:var(--vk-accent-soft);color:var(--vk-accent);border-radius:999px;font-size:10px;font-weight:800;padding:1px 7px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
