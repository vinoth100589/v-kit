<template>
  <div class="vk-splitbtn">
    <v-button class="vk-btn--main" appearance="secondary" :size="size" :disabled="disabled" @click="$emit('click', modelValue)">
      <span style="display:flex;flex-direction:column;align-items:center;gap:3px;line-height:1">
        <span style="font-size:14px">{{ icon }}</span>
        <span class="bar" :style="{ background: modelValue }"></span>
      </span>
    </v-button>
    <v-button ref="arrowBtn" class="vk-btn--arrow" appearance="secondary" :size="size" :disabled="disabled"
      :aria-expanded="open" aria-haspopup="true" aria-label="Pick color"
      @click="open = !open" @keydown="onArrowKeydown">▾</v-button>
    <v-color-picker :model-value="modelValue" :visible="open" :colors="colors"
      :advanced-picker="advancedPicker" :show-alpha="showAlpha"
      @update:model-value="$emit('update:modelValue', $event); $emit('change', $event)"
      @update:visible="open = $event"></v-color-picker>
  </div>
</template>

<script>
import VButton from './VButton.vue'
import VColorPicker from './VColorPicker.vue'
const clickOutside = {
  mounted() {
    this.__vkOut = (e) => { if (this.$el && !this.$el.contains(e.target)) this.onClickOutside && this.onClickOutside(e) }
    document.addEventListener('mousedown', this.__vkOut)
  },
  unmounted() { document.removeEventListener('mousedown', this.__vkOut) }
}
export default {
  name: 'VColorSplitButton',
  components: { VColorPicker, VButton },
  mixins: [clickOutside],
  props: {
    modelValue: { type: String, default: '#e11d48' },
    icon: { type: String, default: 'A' },
    colors: { type: Array, default: () => [] },
    advancedPicker: Boolean,
    showAlpha: Boolean,
    size: { type: String, default: 'medium' },
    disabled: Boolean
  },
  emits: ['update:modelValue', 'change', 'click'],
  data() { return { open: false } },
  watch: {
    open(v) { if (!v) this.$nextTick(() => this.$refs.arrowBtn && this.$refs.arrowBtn.$el.focus()) }
  },
  methods: {
    onClickOutside() { this.open = false },
    onArrowKeydown(e) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.open = true }
      else if (e.key === 'Escape') { this.open = false }
    }
  }
};
</script>

<style>
.vk-splitbtn{display:inline-flex;align-items:stretch;position:relative;vertical-align:middle}
.vk-splitbtn .vk-btn--main{border-top-right-radius:0;border-bottom-right-radius:0}
.vk-splitbtn .vk-btn--arrow{border-top-left-radius:0;border-bottom-left-radius:0;padding:0 10px;margin-left:1.5px;font-size:10px}
.vk-splitbtn .bar{width:18px;height:4px;border-radius:2px;display:block}

/* --- V-Kit shared styles (tokens + 4 themes + btn primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:var(--vk-radius-s);font-family:inherit;font-weight:600;cursor:pointer;transition:.16s;white-space:nowrap;background:var(--vk-surface);color:var(--vk-text)}
.vk-btn:disabled{opacity:.45;cursor:not-allowed}
.vk-btn--md{height:38px;padding:0 18px;font-size:13.5px}
.vk-btn--sm{height:31px;padding:0 13px;font-size:12.5px}
.vk-btn--lg{height:45px;padding:0 24px;font-size:14.5px}
.vk-btn--primary{background:var(--vk-grad);color:var(--vk-on-accent);box-shadow:var(--vk-shadow)}
.vk-btn--primary:hover:not(:disabled){filter:brightness(1.08)}
.vk-btn--secondary{border-color:var(--vk-line-2)}
.vk-btn--secondary:hover:not(:disabled){border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-btn--danger{background:var(--vk-danger);color:#fff}
.vk-btn--ghost{background:transparent;color:var(--vk-accent)}
.vk-btn--ghost:hover:not(:disabled){background:var(--vk-accent-soft)}
.vk-btn--link{background:none;padding:0;height:auto;color:var(--vk-accent)}
.vk-btn--link:hover:not(:disabled){text-decoration:underline}
.vk-spin{width:14px;height:14px;border-radius:50%;border:2px solid currentColor;border-top-color:transparent;animation:vk-rot .7s linear infinite;flex:none}
@keyframes vk-rot{to{transform:rotate(360deg)}}
</style>
