<template>
  <div class="vk-table-wrap">
    <div v-if="loading" class="vk-table-loading"><span class="vk-spin" style="border-top-color:var(--vk-accent)"></span> Loading…</div>
    <table v-else class="vk-table" :class="{ striped, hover, sticky: stickyHeader }">
      <thead><tr>
        <th v-if="expandable" class="chkcol"></th>
        <th v-if="selectable" class="chkcol">
          <input type="checkbox" :checked="allSelected" @change="toggleAll($event.target.checked)">
        </th>
        <th v-for="c in columns" :key="c.key" :class="{ srt: c.sortable }" @click="sort(c)">
          {{ c.label }}<span v-if="sortKey === c.key" class="ar">{{ dir === 1 ? '▲' : '▼' }}</span>
        </th>
      </tr></thead>
      <tbody>
        <template v-for="(r, i) in sorted" :key="i">
          <tr :class="{ sel: isSelected(r), clk: rowClickable }" @click="onRowClick(r)">
            <td v-if="expandable" class="chkcol">
              <button type="button" class="exp" :class="{ open: isExpanded(r) }" aria-label="Expand row" @click.stop="toggleExpand(r)">▸</button>
            </td>
            <td v-if="selectable" class="chkcol" @click.stop>
              <input type="checkbox" :checked="isSelected(r)" @change="toggleRow(r, $event.target.checked)">
            </td>
            <td v-for="c in columns" :key="c.key">
              <slot :name="'cell-' + c.key" :row="r" :value="r[c.key]">{{ r[c.key] }}</slot>
            </td>
          </tr>
          <tr v-if="expandable && isExpanded(r)" class="detail">
            <td :colspan="columns.length + (selectable ? 1 : 0) + (expandable ? 1 : 0)">
              <slot name="expand" :row="r">{{ r }}</slot>
            </td>
          </tr>
        </template>
        <tr v-if="!rows.length"><td :colspan="columns.length + (selectable ? 1 : 0) + (expandable ? 1 : 0)" class="none">{{ emptyText }}</td></tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'VTable',
  props: {
    columns: { type: Array, required: true },   // [{key, label, sortable?}]
    rows: { type: Array, default: () => [] },
    rowKey: { type: String, default: null },   // property to use as the identity for selection; falls back to row reference
    selected: { type: Array, default: () => [] },   // v-model:selected — selected rows (or row-key values)
    selectable: Boolean,
    loading: Boolean,
    stickyHeader: Boolean,
    striped: Boolean,
    hover: Boolean,
    rowClickable: Boolean,   // adds hover affordance + emits rowclick when a row is clicked
    expandable: Boolean,      // adds a per-row expand toggle revealing the "expand" slot
    emptyText: { type: String, default: 'No records' }
  },
  emits: ['update:selected', 'rowclick'],
  data() { return { sortKey: '', dir: 1, expanded: [] } },
  computed: {
    sorted() {
      if (!this.sortKey) return this.rows
      return [...this.rows].sort((a, b) => {
        const x = a[this.sortKey], y = b[this.sortKey]
        return (x > y ? 1 : x < y ? -1 : 0) * this.dir
      })
    },
    allSelected() { return this.rows.length > 0 && this.rows.every(r => this.isSelected(r)) }
  },
  methods: {
    keyOf(r) { return this.rowKey ? r[this.rowKey] : r },
    isSelected(r) { return this.selected.includes(this.keyOf(r)) },
    toggleRow(r, checked) {
      const k = this.keyOf(r)
      const next = checked ? [...this.selected, k] : this.selected.filter(x => x !== k)
      this.$emit('update:selected', next)
    },
    toggleAll(checked) { this.$emit('update:selected', checked ? this.rows.map(this.keyOf) : []) },
    sort(c) {
      if (!c.sortable) return
      if (this.sortKey === c.key) this.dir *= -1
      else { this.sortKey = c.key; this.dir = 1 }
    },
    isExpanded(r) { return this.expanded.includes(this.keyOf(r)) },
    toggleExpand(r) {
      const k = this.keyOf(r)
      const at = this.expanded.indexOf(k)
      at > -1 ? this.expanded.splice(at, 1) : this.expanded.push(k)
    },
    onRowClick(r) { if (this.rowClickable) this.$emit('rowclick', r) }
  }
};
</script>

<style>
.vk-table-wrap{width:100%;overflow-x:auto;border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);background:var(--vk-surface)}
.vk-table{width:100%;border-collapse:collapse;font-size:13px}
.vk-table th{text-align:left;background:var(--vk-sunken);padding:11px 15px;font-size:10.5px;font-weight:800;letter-spacing:.09em;text-transform:uppercase;color:var(--vk-text-3);white-space:nowrap}
.vk-table.sticky th{position:sticky;top:0;z-index:2}
.vk-table th.srt{cursor:pointer;user-select:none}
.vk-table th.srt:hover{color:var(--vk-accent)}
.vk-table th .ar{font-size:9px;margin-left:5px;color:var(--vk-accent)}
.vk-table td{padding:11px 15px;border-top:1px solid var(--vk-line)}
.vk-table .chkcol{width:36px;text-align:center;padding-left:14px}
.vk-table tr.sel td{background:var(--vk-accent-soft)}
.vk-table.striped tbody tr:nth-child(even){background:var(--vk-sunken)}
.vk-table.striped tbody tr.sel:nth-child(even) td{background:var(--vk-accent-soft)}
.vk-table.hover tbody tr:hover td{background:var(--vk-accent-soft)}
.vk-table .none{text-align:center;color:var(--vk-text-3);padding:30px}
.vk-table tr.clk{cursor:pointer}
.vk-table .exp{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:11px;transition:.15s;padding:2px}
.vk-table .exp.open{transform:rotate(90deg)}
.vk-table tr.detail td{background:var(--vk-sunken);border-top:none;padding:14px 15px 14px 40px;font-size:12.5px;color:var(--vk-text-2)}
.vk-table-loading{display:flex;align-items:center;justify-content:center;gap:10px;padding:40px;color:var(--vk-text-2);font-size:13px}

/* --- V-Kit shared styles (tokens + 4 themes + btn, field primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:var(--vk-radius-s);font-family:inherit;font-weight:600;cursor:pointer;transition:.16s;white-space:nowrap;background:var(--vk-surface);color:var(--vk-text)}
.vk-btn:disabled{opacity:.45;cursor:not-allowed}
.vk-btn--md{height:38px;padding:0 18px;font-size:13.5px}
.vk-btn--sm{height:31px;padding:0 13px;font-size:12.5px}
.vk-btn--lg{height:45px;padding:0 24px;font-size:14.5px}
.vk-btn--primary{background:var(--vk-grad);color:var(--vk-on-accent);box-shadow:var(--vk-shadow)}
.vk-btn--primary:hover:not(:disabled){filter:brightness(1.08)}
.vk-btn--secondary{border-color:var(--vk-line-2)}
.vk-btn--secondary:hover:not(:disabled){border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-btn--danger{background:var(--vk-danger);color:#fff}
.vk-btn--ghost{background:transparent;color:var(--vk-accent)}
.vk-btn--ghost:hover:not(:disabled){background:var(--vk-accent-soft)}
.vk-btn--link{background:none;padding:0;height:auto;color:var(--vk-accent)}
.vk-btn--link:hover:not(:disabled){text-decoration:underline}
.vk-spin{width:14px;height:14px;border-radius:50%;border:2px solid currentColor;border-top-color:transparent;animation:vk-rot .7s linear infinite;flex:none}
@keyframes vk-rot{to{transform:rotate(360deg)}}

.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}
</style>
