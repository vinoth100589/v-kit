<template>
  <div class="vk-slider vk-dslider">
    <div class="track" ref="track">
      <div class="fill" :style="{ left: pctOf(fromValue) + '%', width: (pctOf(toValue) - pctOf(fromValue)) + '%' }"></div>
      <div class="thumb" :style="{ left: pctOf(fromValue) + '%' }" :tabindex="disabled ? -1 : 0" role="slider"
        aria-label="Minimum value" :aria-valuenow="fromValue" :aria-valuemin="min" :aria-valuemax="toValue"
        :aria-disabled="disabled" @mousedown="drag('from', $event)" @keydown="onKeydown('from', $event)">
        <span class="tip" v-if="tooltip">{{ fromValue }}</span>
      </div>
      <div class="thumb" :style="{ left: pctOf(toValue) + '%' }" :tabindex="disabled ? -1 : 0" role="slider"
        aria-label="Maximum value" :aria-valuenow="toValue" :aria-valuemin="fromValue" :aria-valuemax="max"
        :aria-disabled="disabled" @mousedown="drag('to', $event)" @keydown="onKeydown('to', $event)">
        <span class="tip" v-if="tooltip">{{ toValue }}</span>
      </div>
      <div v-if="marks.length" class="marklabels">
        <span v-for="m in marks" :key="m.value" class="mlabel" :style="{ left: pctOf(m.value) + '%' }">{{ m.label }}</span>
      </div>
    </div>
    <span class="minmax">{{ fromValue }} – {{ toValue }}</span>
  </div>
</template>

<script>
export default {
  name: 'VDoubleSlider',
  props: {
    fromValue: { type: Number, default: 20 },
    toValue: { type: Number, default: 80 },
    min: { type: Number, default: 0 }, max: { type: Number, default: 100 },
    step: { type: Number, default: 1 },
    minRangeDiff: { type: Number, default: 0 },
    marks: { type: Array, default: () => [] },
    tooltip: { type: Boolean, default: true },
    disabled: Boolean
  },
  emits: ['update:fromValue', 'update:toValue', 'change', 'slide'],
  methods: {
    pctOf(v) { return ((v - this.min) / (this.max - this.min)) * 100 },
    drag(which, e) {
      if (this.disabled) return
      e.preventDefault()
      const mv = (ev) => {
        const r = this.$refs.track.getBoundingClientRect()
        let v = this.min + ((ev.clientX - r.left) / r.width) * (this.max - this.min)
        v = Math.round(v / this.step) * this.step
        v = Math.min(this.max, Math.max(this.min, v))
        if (which === 'from') {
          v = Math.min(v, this.toValue - this.minRangeDiff)
          this.$emit('update:fromValue', v)
        } else {
          v = Math.max(v, this.fromValue + this.minRangeDiff)
          this.$emit('update:toValue', v)
        }
        this.$emit('slide', { from: this.fromValue, to: this.toValue })
      }
      const up = () => {
        this.$emit('change', { from: this.fromValue, to: this.toValue })
        document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up)
      }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up)
    },
    nudgeOne(which, d) {
      if (this.disabled) return
      if (which === 'from') {
        const v = Math.min(this.max, Math.max(this.min, Math.min(this.fromValue + d, this.toValue - this.minRangeDiff)))
        this.$emit('update:fromValue', v)
      } else {
        const v = Math.min(this.max, Math.max(this.min, Math.max(this.toValue + d, this.fromValue + this.minRangeDiff)))
        this.$emit('update:toValue', v)
      }
      this.$emit('change', { from: this.fromValue, to: this.toValue })
    },
    onKeydown(which, e) {
      if (this.disabled) return
      if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); this.nudgeOne(which, -this.step) }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); this.nudgeOne(which, this.step) }
      else if (e.key === 'PageDown') { e.preventDefault(); this.nudgeOne(which, -this.step * 10) }
      else if (e.key === 'PageUp') { e.preventDefault(); this.nudgeOne(which, this.step * 10) }
      else if (e.key === 'Home') {
        e.preventDefault()
        which === 'from' ? this.$emit('update:fromValue', this.min) : this.$emit('update:toValue', this.fromValue + this.minRangeDiff)
      } else if (e.key === 'End') {
        e.preventDefault()
        which === 'from' ? this.$emit('update:fromValue', this.toValue - this.minRangeDiff) : this.$emit('update:toValue', this.max)
      }
    }
  }
};
</script>

<style>
.vk-slider{display:flex;align-items:center;gap:14px;min-width:260px;padding:14px 0}
.vk-slider .track{position:relative;flex:1;height:7px;border-radius:999px;background:var(--vk-sunken);cursor:pointer}
.vk-slider .fill{position:absolute;top:0;bottom:0;left:0;border-radius:999px;background:var(--vk-grad)}
.vk-slider .thumb{position:absolute;top:50%;transform:translate(-50%,-50%);width:19px;height:19px;border-radius:50%;background:var(--vk-surface);border:2.5px solid var(--vk-accent);box-shadow:var(--vk-shadow);cursor:grab}
.vk-slider .thumb:active{cursor:grabbing}
.vk-slider .thumb:focus-visible{outline:2px solid var(--vk-accent);outline-offset:2px}
.vk-slider .tip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);background:var(--vk-shell);color:#fff;border-radius:6px;font-size:11px;padding:2px 8px;white-space:nowrap}
.vk-slider .marklabels{position:absolute;top:calc(100% + 11px);left:0;right:0;height:14px}
.vk-slider .mlabel{position:absolute;transform:translateX(-50%);font-size:10.5px;color:var(--vk-text-3);white-space:nowrap}
.vk-slider .minmax{font-size:11.5px;color:var(--vk-text-3);white-space:nowrap}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
