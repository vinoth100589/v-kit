<template>
  <div class="vk-scroll-wrap" :class="{ fade: fadeEdges }" :style="{ height, width }">
    <div ref="box" class="vk-scroll" @scroll="onScroll">
      <slot></slot>
    </div>
    <div v-if="fadeEdges" class="edge top" :style="{ opacity: topOpacity }"></div>
    <div v-if="fadeEdges" class="edge bot" :style="{ opacity: botOpacity }"></div>
  </div>
</template>

<script>
export default {
  name: 'VScrollbar',
  props: {
    height: { type: String, default: '220px' },
    width: { type: String, default: '100%' },
    fadeEdges: Boolean   // shows a soft shadow at the top/bottom when there's more content to scroll
  },
  emits: ['scroll'],
  data() { return { topOpacity: 0, botOpacity: 1 } },
  methods: {
    onScroll(e) {
      this.$emit('scroll', e)
      if (!this.fadeEdges) return
      const el = e.target
      this.topOpacity = Math.min(1, el.scrollTop / 24)
      this.botOpacity = Math.min(1, (el.scrollHeight - el.clientHeight - el.scrollTop) / 24)
    }
  },
  mounted() { if (this.fadeEdges) this.onScroll({ target: this.$refs.box }) }
};
</script>

<style>
.vk-scroll-wrap{position:relative;border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);background:var(--vk-surface)}
.vk-scroll{overflow:auto;padding:14px;height:100%;box-sizing:border-box}
.vk-scroll::-webkit-scrollbar{width:9px;height:9px}
.vk-scroll::-webkit-scrollbar-track{background:transparent}
.vk-scroll::-webkit-scrollbar-thumb{background:var(--vk-line-2);border-radius:999px;border:2px solid var(--vk-surface)}
.vk-scroll::-webkit-scrollbar-thumb:hover{background:var(--vk-accent)}
.vk-scroll{scrollbar-width:thin;scrollbar-color:var(--vk-line-2) transparent}
.vk-scroll-wrap.fade .edge{position:absolute;left:0;right:0;height:22px;pointer-events:none;transition:opacity .15s}
.vk-scroll-wrap.fade .edge.top{top:0;background:linear-gradient(var(--vk-surface),transparent);border-radius:var(--vk-radius) var(--vk-radius) 0 0}
.vk-scroll-wrap.fade .edge.bot{bottom:0;background:linear-gradient(transparent,var(--vk-surface));border-radius:0 0 var(--vk-radius) var(--vk-radius)}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
