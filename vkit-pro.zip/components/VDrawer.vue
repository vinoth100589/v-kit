<template>
  <teleport to="body">
    <div v-if="modelValue" class="vk-drawer-mask" @click.self="!persistent && close()">
      <div class="vk-drawer" :class="'vk-drawer--' + side" :style="{ width: sizeWidth }">
        <div class="hd">
          <span>{{ title }}</span>
          <v-button v-if="!persistent" appearance="ghost" size="small" text="✕" aria-label="Close" @click="close"></v-button>
        </div>
        <div class="bd"><slot></slot></div>
        <div v-if="$slots.footer" class="ft"><slot name="footer"></slot></div>
      </div>
    </div>
  </teleport>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VDrawer',
  components: { VButton },
  props: {
    modelValue: Boolean,
    title: { type: String, default: 'Drawer' },
    side: { type: String, default: 'right' },   // left | right
    size: { type: String, default: 'medium' },   // small | medium | large — overridden by explicit width
    width: String,
    persistent: Boolean   // hides the close control and ignores backdrop clicks
  },
  emits: ['update:modelValue', 'open', 'close'],
  computed: {
    sizeWidth() {
      if (this.width) return this.width
      return { small: '280px', medium: '340px', large: '480px' }[this.size] || '340px'
    }
  },
  watch: { modelValue(v) { this.$emit(v ? 'open' : 'close') } },
  methods: {
    open() { this.$emit('update:modelValue', true) },
    close() { this.$emit('update:modelValue', false) }
  }
};
</script>

<style>
.vk-drawer-mask{position:fixed;inset:0;background:color-mix(in srgb,var(--vk-shell) 50%,transparent);z-index:940}
.vk-drawer{position:fixed;top:0;bottom:0;background:var(--vk-raised);box-shadow:var(--vk-shadow-pop);display:flex;flex-direction:column;max-width:92vw}
.vk-drawer--right{right:0;border-radius:16px 0 0 16px;animation:vk-dr-r .22s ease}
.vk-drawer--left{left:0;border-radius:0 16px 16px 0;animation:vk-dr-l .22s ease}
@keyframes vk-dr-r{from{transform:translateX(40px);opacity:0}to{transform:none;opacity:1}}
@keyframes vk-dr-l{from{transform:translateX(-40px);opacity:0}to{transform:none;opacity:1}}
.vk-drawer .hd{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--vk-line);font-weight:750;font-size:15px}
.vk-drawer .bd{padding:18px 20px;overflow-y:auto;flex:1;font-size:13.5px;color:var(--vk-text-2)}
.vk-drawer .ft{padding:14px 20px;border-top:1px solid var(--vk-line);display:flex;justify-content:flex-end;gap:9px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
