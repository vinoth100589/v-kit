<template>
  <div class="vk-cal-core">
    <div class="hd">
      <button type="button" aria-label="Previous month" @click="move(-1)">‹</button>
      <span>{{ monthLabel }}</span>
      <button type="button" aria-label="Next month" @click="move(1)">›</button>
    </div>
    <div class="wk"><span v-for="w in weekdayLabels" :key="w">{{ w }}</span></div>
    <div class="gr">
      <button type="button" v-for="c in grid" :key="c.key" class="dy"
        :class="{ out: c.out, today: c.s === todayStr, sel: c.s === modelValue || c.s === rangeStart || c.s === rangeEnd, inrange: inRange(c.s) }"
        :disabled="isDisabled(c.s, c.d)" @click="$emit('pick', c.s)">{{ c.d.getDate() }}</button>
    </div>
  </div>
</template>

<script>
export function fmt(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
}
export default {
  name: 'VCalendarCore',
  props: {
    modelValue: String, min: String, max: String,
    rangeStart: String, rangeEnd: String,
    initialMonth: String,
    weekStartsOn: { type: Number, default: 0 },   // 0 = Sunday, 1 = Monday
    disabledDates: { type: Function, default: null }   // (dateStr, Date) => boolean
  },
  emits: ['pick'],
  data() {
    const base = this.modelValue || this.rangeStart || this.initialMonth
    const d = base ? new Date(base + 'T00:00:00') : new Date()
    return { vy: d.getFullYear(), vm: d.getMonth() }
  },
  computed: {
    monthLabel() { return new Date(this.vy, this.vm, 1).toLocaleString('default', { month: 'long', year: 'numeric' }) },
    todayStr() { return fmt(new Date()) },
    weekdayLabels() {
      const base = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']
      return base.slice(this.weekStartsOn).concat(base.slice(0, this.weekStartsOn))
    },
    grid() {
      const first = new Date(this.vy, this.vm, 1).getDay()
      const start = ((first - this.weekStartsOn) % 7 + 7) % 7
      const out = []
      for (let i = 0; i < 42; i++) {
        const d = new Date(this.vy, this.vm, i - start + 1)
        out.push({ d, s: fmt(d), out: d.getMonth() !== this.vm, key: i })
      }
      return out
    }
  },
  methods: {
    move(n) { const m = this.vm + n; this.vy += Math.floor(m / 12); this.vm = ((m % 12) + 12) % 12 },
    isDisabled(s, d) {
      if (this.min && s < this.min) return true
      if (this.max && s > this.max) return true
      if (this.disabledDates && this.disabledDates(s, d)) return true
      return false
    },
    inRange(s) { return this.rangeStart && this.rangeEnd && s > this.rangeStart && s < this.rangeEnd }
  }
};
</script>

<style>
.vk-cal-core .hd{display:flex;align-items:center;justify-content:space-between;font-weight:700;font-size:13px;margin-bottom:10px}
.vk-cal-core .hd button{border:none;background:var(--vk-sunken);width:27px;height:27px;border-radius:8px;cursor:pointer;color:var(--vk-text-2);font-size:14px;font-family:inherit}
.vk-cal-core .hd button:hover{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-cal-core .wk{display:grid;grid-template-columns:repeat(7,1fr);font-size:10px;font-weight:700;letter-spacing:.08em;color:var(--vk-text-3);text-align:center;margin-bottom:5px;text-transform:uppercase}
.vk-cal-core .gr{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}
.vk-cal-core .dy{border:none;background:none;height:31px;border-radius:9px;cursor:pointer;font-size:12.5px;color:var(--vk-text);font-family:inherit;position:relative}
.vk-cal-core .dy:hover:not(:disabled){background:var(--vk-sunken)}
.vk-cal-core .dy.out{color:var(--vk-text-3);opacity:.5}
.vk-cal-core .dy.today::after{content:"";position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:var(--vk-accent)}
.vk-cal-core .dy.sel{background:var(--vk-grad);color:var(--vk-on-accent);font-weight:700}
.vk-cal-core .dy.inrange{background:var(--vk-accent-soft);border-radius:0}
.vk-cal-core .dy:disabled{opacity:.22;cursor:not-allowed}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
