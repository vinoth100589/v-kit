<template>
  <div class="vk-field">
    <label v-if="label">{{ label }}</label>
    <div class="vk-inwrap">
      <input class="vk-input" :type="show ? 'text' : 'password'" :value="modelValue"
        :placeholder="placeholder" :disabled="disabled" style="padding-right:38px"
        @input="$emit('update:modelValue', $event.target.value)">
      <span class="vk-affix vk-affix--r">
        <button :aria-label="show ? 'Hide password' : 'Show password'" @click="show = !show">{{ show ? '🙈' : '👁' }}</button>
      </span>
    </div>
    <div v-if="strengthMeter" class="vk-pw-meter">
      <span v-for="n in 4" :key="n" class="seg" :class="{ on: n <= score }" :data-s="score"></span>
      <em>{{ ['', 'weak', 'fair', 'good', 'strong'][score] }}</em>
    </div>
    <ul v-if="showRequirements" class="vk-pw-req">
      <li :class="{ ok: (modelValue || '').length >= 8 }">{{ (modelValue || '').length >= 8 ? '✓' : '·' }} At least 8 characters</li>
      <li :class="{ ok: /[a-z]/.test(modelValue || '') && /[A-Z]/.test(modelValue || '') }">{{ /[a-z]/.test(modelValue || '') && /[A-Z]/.test(modelValue || '') ? '✓' : '·' }} Upper &amp; lowercase letters</li>
      <li :class="{ ok: /\d/.test(modelValue || '') }">{{ /\d/.test(modelValue || '') ? '✓' : '·' }} At least one number</li>
      <li :class="{ ok: /[^A-Za-z0-9]/.test(modelValue || '') }">{{ /[^A-Za-z0-9]/.test(modelValue || '') ? '✓' : '·' }} At least one symbol</li>
    </ul>
    <span v-if="hint" class="hint">{{ hint }}</span>
  </div>
</template>

<script>
export default {
  name: 'VPasswordField',
  props: {
    modelValue: { type: String, default: '' },
    label: String, placeholder: String, hint: String,
    strengthMeter: { type: Boolean, default: true },
    showRequirements: Boolean,   // checklist of common password rules
    disabled: Boolean
  },
  emits: ['update:modelValue'],
  data() { return { show: false } },
  computed: {
    score() {
      const v = this.modelValue || ''
      if (!v) return 0
      let s = 0
      if (v.length >= 8) s++
      if (/[A-Z]/.test(v) && /[a-z]/.test(v)) s++
      if (/\d/.test(v)) s++
      if (/[^A-Za-z0-9]/.test(v)) s++
      return Math.max(1, s)
    }
  }
};
</script>

<style>
.vk-pw-meter{display:flex;align-items:center;gap:5px}
.vk-pw-meter .seg{flex:1;height:5px;border-radius:99px;background:var(--vk-sunken);transition:.2s}
.vk-pw-meter .seg.on[data-s="1"]{background:var(--vk-danger)}
.vk-pw-meter .seg.on[data-s="2"]{background:var(--vk-warning)}
.vk-pw-meter .seg.on[data-s="3"]{background:var(--vk-info)}
.vk-pw-meter .seg.on[data-s="4"]{background:var(--vk-success)}
.vk-pw-meter em{font-style:normal;font-size:10.5px;color:var(--vk-text-3);min-width:42px;text-align:right}
.vk-pw-req{list-style:none;margin:2px 0 0;padding:0;display:flex;flex-direction:column;gap:2px}
.vk-pw-req li{font-size:11.5px;color:var(--vk-text-3)}
.vk-pw-req li.ok{color:var(--vk-success)}

/* --- V-Kit shared styles (tokens + 4 themes + field primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}
</style>
