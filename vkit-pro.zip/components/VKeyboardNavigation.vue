<template>
  <div class="vk-keynav" tabindex="0" @keydown="onKey">
    <div v-for="(it, i) in items" :key="i" class="it" :class="{ focus: idx === i }" @click="setIdx(i)">
      <slot :item="it" :index="i" :focused="idx === i">{{ it }}</slot>
    </div>
    <div class="tip">Focus this list, then use ↑ ↓ (wrap-around {{ wrapAround ? 'on' : 'off' }}), Enter to select{{ typeahead ? ', or type to jump' : '' }}</div>
  </div>
</template>

<script>
export default {
  name: 'VKeyboardNavigation',
  props: {
    items: { type: Array, default: () => [] },
    wrapAround: { type: Boolean, default: true },
    direction: { type: String, default: 'vertical' },
    typeahead: Boolean   // typing letters jumps focus to the next item that starts with them
  },
  emits: ['focusmove', 'select'],
  data() { return { idx: 0, buffer: '', bufTimer: null } },
  methods: {
    setIdx(i) { this.idx = i; this.$emit('focusmove', i) },
    onKey(e) {
      const fwd = this.direction === 'vertical' ? 'ArrowDown' : 'ArrowRight'
      const back = this.direction === 'vertical' ? 'ArrowUp' : 'ArrowLeft'
      if (e.key === fwd) {
        e.preventDefault()
        this.setIdx(this.idx + 1 >= this.items.length ? (this.wrapAround ? 0 : this.idx) : this.idx + 1)
      } else if (e.key === back) {
        e.preventDefault()
        this.setIdx(this.idx - 1 < 0 ? (this.wrapAround ? this.items.length - 1 : 0) : this.idx - 1)
      } else if (e.key === 'Enter') this.$emit('select', this.idx)
      else if (this.typeahead && e.key.length === 1 && /[a-z0-9]/i.test(e.key)) {
        clearTimeout(this.bufTimer)
        this.buffer += e.key.toLowerCase()
        this.bufTimer = setTimeout(() => { this.buffer = '' }, 600)
        const at = this.items.findIndex(it => String(it).toLowerCase().startsWith(this.buffer))
        if (at > -1) this.setIdx(at)
      }
    }
  }
};
</script>

<style>
.vk-keynav{outline:none;display:flex;flex-direction:column;gap:6px;min-width:250px;border-radius:var(--vk-radius);padding:4px}
.vk-keynav:focus-visible{box-shadow:0 0 0 3px color-mix(in srgb,var(--vk-accent) 30%,transparent)}
.vk-keynav .it{border:1.5px solid var(--vk-line);border-radius:var(--vk-radius-s);padding:10px 14px;font-size:13px;background:var(--vk-surface);cursor:pointer}
.vk-keynav .it.focus{border-color:var(--vk-accent);background:var(--vk-accent-soft);color:var(--vk-accent);font-weight:650}
.vk-keynav .tip{font-size:11px;color:var(--vk-text-3);padding:4px 2px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
