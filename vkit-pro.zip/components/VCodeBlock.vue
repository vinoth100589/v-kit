<template>
  <div class="vk-code">
    <div class="hd">
      <span class="lang">{{ language }}</span>
      <v-button appearance="ghost" size="small" :text="copied ? '✓ Copied' : 'Copy'" @click="copy"></v-button>
    </div>
    <pre><code><span v-for="(line, i) in lines" :key="i" class="ln" :class="{ hl: highlightLines.includes(i + 1) }"><span v-if="lineNumbers" class="no">{{ i + 1 }}</span>{{ line }}
</span></code></pre>
  </div>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VCodeBlock',
  components: { VButton },
  props: {
    code: { type: String, default: '' },
    language: { type: String, default: 'text' },
    lineNumbers: Boolean,
    highlightLines: { type: Array, default: () => [] }   // 1-based line numbers to visually emphasize
  },
  emits: ['copy'],
  data() { return { copied: false } },
  computed: { lines() { return this.code.split('\n') } },
  methods: {
    async copy() {
      try { await navigator.clipboard.writeText(this.code) }
      catch (e) {
        const ta = document.createElement('textarea')
        ta.value = this.code; document.body.appendChild(ta); ta.select()
        document.execCommand('copy'); ta.remove()
      }
      this.copied = true; this.$emit('copy', this.code)
      setTimeout(() => this.copied = false, 1600)
    }
  }
};
</script>

<style>
.vk-code{border-radius:var(--vk-radius);overflow:hidden;background:var(--vk-shell);width:100%;border:1px solid var(--vk-shell-line)}
.vk-code .hd{display:flex;align-items:center;justify-content:space-between;padding:7px 9px 7px 16px;border-bottom:1px solid var(--vk-shell-line)}
.vk-code .lang{font-size:10.5px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--vk-shell-text)}
.vk-code pre{margin:0;padding:16px 0;overflow-x:auto;color:#dbe2ff;font-family:var(--vk-mono);font-size:12.5px;line-height:1.65}
.vk-code .ln{display:block;padding:0 18px}
.vk-code .ln.hl{background:rgba(124,58,237,.18);box-shadow:inset 3px 0 var(--vk-accent)}
.vk-code .no{display:inline-block;width:28px;color:var(--vk-shell-text);opacity:.6;user-select:none}
.vk-code .vk-btn--ghost{color:var(--vk-shell-text)}
.vk-code .vk-btn--ghost:hover:not(:disabled){background:var(--vk-shell-2);color:#fff}

/* --- V-Kit shared styles (tokens + 4 themes + btn primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:var(--vk-radius-s);font-family:inherit;font-weight:600;cursor:pointer;transition:.16s;white-space:nowrap;background:var(--vk-surface);color:var(--vk-text)}
.vk-btn:disabled{opacity:.45;cursor:not-allowed}
.vk-btn--md{height:38px;padding:0 18px;font-size:13.5px}
.vk-btn--sm{height:31px;padding:0 13px;font-size:12.5px}
.vk-btn--lg{height:45px;padding:0 24px;font-size:14.5px}
.vk-btn--primary{background:var(--vk-grad);color:var(--vk-on-accent);box-shadow:var(--vk-shadow)}
.vk-btn--primary:hover:not(:disabled){filter:brightness(1.08)}
.vk-btn--secondary{border-color:var(--vk-line-2)}
.vk-btn--secondary:hover:not(:disabled){border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-btn--danger{background:var(--vk-danger);color:#fff}
.vk-btn--ghost{background:transparent;color:var(--vk-accent)}
.vk-btn--ghost:hover:not(:disabled){background:var(--vk-accent-soft)}
.vk-btn--link{background:none;padding:0;height:auto;color:var(--vk-accent)}
.vk-btn--link:hover:not(:disabled){text-decoration:underline}
.vk-spin{width:14px;height:14px;border-radius:50%;border:2px solid currentColor;border-top-color:transparent;animation:vk-rot .7s linear infinite;flex:none}
@keyframes vk-rot{to{transform:rotate(360deg)}}
</style>
