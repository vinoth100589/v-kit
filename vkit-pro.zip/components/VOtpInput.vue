<template>
  <div class="vk-otp" :class="{ err: !!error }">
    <input v-for="i in length" :key="i" ref="cells" :type="masked ? 'password' : 'text'"
      :inputmode="type === 'alphanumeric' ? 'text' : 'numeric'" maxlength="1"
      :value="(modelValue || '')[i - 1] || ''" :disabled="disabled"
      @input="onInput(i - 1, $event)" @keydown="onKey(i - 1, $event)" @paste.prevent="onPaste($event)">
    <span v-if="error" class="msg">{{ error }}</span>
  </div>
</template>

<script>
export default {
  name: 'VOtpInput',
  props: {
    modelValue: { type: String, default: '' },
    length: { type: Number, default: 6 },
    type: { type: String, default: 'numeric' },   // numeric | alphanumeric
    masked: Boolean,   // show dots instead of the typed character
    error: String,
    disabled: Boolean
  },
  emits: ['update:modelValue', 'complete'],
  methods: {
    sanitize(v) { return this.type === 'alphanumeric' ? v.replace(/[^A-Za-z0-9]/g, '') : v.replace(/\D/g, '') },
    commit(chars) {
      const v = chars.join('').slice(0, this.length)
      this.$emit('update:modelValue', v)
      if (v.length === this.length) this.$emit('complete', v)
    },
    onInput(idx, e) {
      const ch = this.sanitize(e.target.value).slice(-1)
      const chars = (this.modelValue || '').padEnd(this.length).split('')
      chars[idx] = ch || ' '
      this.commit(chars.map(c => c.trim() ? c : '').slice(0, idx + (ch ? 1 : 0)).concat(chars.slice(idx + 1).map(c => c.trim() ? c : '')))
      if (ch && idx < this.length - 1) this.$refs.cells[idx + 1].focus()
    },
    onKey(idx, e) {
      if (e.key === 'Backspace' && !e.target.value && idx > 0) this.$refs.cells[idx - 1].focus()
      else if (e.key === 'ArrowLeft' && idx > 0) { e.preventDefault(); this.$refs.cells[idx - 1].focus() }
      else if (e.key === 'ArrowRight' && idx < this.length - 1) { e.preventDefault(); this.$refs.cells[idx + 1].focus() }
      else if (e.key === 'Home') { e.preventDefault(); this.$refs.cells[0].focus() }
      else if (e.key === 'End') { e.preventDefault(); this.$refs.cells[this.length - 1].focus() }
    },
    onPaste(e) {
      const chars = this.sanitize(e.clipboardData.getData('text') || '').slice(0, this.length)
      this.commit(chars.split(''))
      const at = Math.min(chars.length, this.length - 1)
      this.$refs.cells[at] && this.$refs.cells[at].focus()
    }
  }
};
</script>

<style>
.vk-otp{display:inline-flex;gap:9px;align-items:center;flex-wrap:wrap}
.vk-otp input{width:44px;height:52px;text-align:center;font-size:21px;font-weight:800;font-family:var(--vk-mono);border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);background:var(--vk-surface);color:var(--vk-text);outline:none;transition:.15s}
.vk-otp input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-otp.err input{border-color:var(--vk-danger)}
.vk-otp .msg{width:100%;font-size:11.5px;color:var(--vk-danger)}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
