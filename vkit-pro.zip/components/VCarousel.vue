<template>
  <div class="vk-carousel" :style="{ height }" tabindex="0" role="region" aria-roledescription="carousel"
    @mouseenter="pauseOnHover && stop()" @mouseleave="pauseOnHover && start()"
    @focusin="pauseOnHover && stop()" @focusout="pauseOnHover && start()" @keydown="onKeydown">
    <div class="trk" :style="{ transform: 'translateX(-' + idx * 100 + '%)' }">
      <div v-for="(s, i) in slides" :key="i" class="sld" :style="{ background: s.color || 'var(--vk-grad)' }"
        :aria-hidden="i !== idx">
        <img v-if="s.image" :src="s.image" :alt="s.title">
        <div v-if="s.title" class="st">{{ s.title }}</div>
        <div v-if="s.content" class="sc">{{ s.content }}</div>
      </div>
    </div>
    <button class="nv l" aria-label="Previous slide" @click="go(idx - 1)">‹</button>
    <button class="nv r" aria-label="Next slide" @click="go(idx + 1)">›</button>
    <div class="dots"><button v-for="(s, i) in slides" :key="i" :class="{ on: i === idx }" :aria-label="'Slide ' + (i + 1)" @click="go(i)"></button></div>
    <div v-if="showThumbnails" class="thumbs">
      <button v-for="(s, i) in slides" :key="'t' + i" class="tb" :class="{ on: i === idx }"
        :style="{ background: s.image ? 'url(' + s.image + ') center/cover' : (s.color || 'var(--vk-grad)') }"
        @click="go(i)"></button>
    </div>
    <span class="vk-sr-only" aria-live="polite">Slide {{ idx + 1 }} of {{ slides.length }}{{ slides[idx] && slides[idx].title ? ': ' + slides[idx].title : '' }}</span>
  </div>
</template>

<script>
export default {
  name: 'VCarousel',
  props: {
    slides: { type: Array, default: () => [] },   // [{title?, content?, image?, color?}]
    autoplay: Boolean,
    interval: { type: Number, default: 4000 },
    pauseOnHover: { type: Boolean, default: true },
    showThumbnails: Boolean,
    height: { type: String, default: '240px' }
  },
  emits: ['change'],
  data() { return { idx: 0 } },
  methods: {
    go(i) { const n = this.slides.length || 1; this.idx = ((i % n) + n) % n; this.$emit('change', this.idx) },
    start() { if (this.autoplay && !this._t) this._t = setInterval(() => this.go(this.idx + 1), this.interval) },
    stop() { clearInterval(this._t); this._t = null },
    onKeydown(e) {
      if (e.key === 'ArrowLeft') { e.preventDefault(); this.go(this.idx - 1) }
      else if (e.key === 'ArrowRight') { e.preventDefault(); this.go(this.idx + 1) }
      else if (e.key === 'Home') { e.preventDefault(); this.go(0) }
      else if (e.key === 'End') { e.preventDefault(); this.go(this.slides.length - 1) }
    }
  },
  mounted() { this.start() },
  unmounted() { this.stop() }
};
</script>

<style>
.vk-carousel{position:relative;width:100%;overflow:hidden;border-radius:var(--vk-radius)}
.vk-carousel .trk{display:flex;transition:transform .45s ease;height:100%}
.vk-carousel .sld{flex:0 0 100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:7px;color:#fff;text-align:center;padding:26px;position:relative}
.vk-carousel .sld img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.vk-carousel .st{font-size:21px;font-weight:800;z-index:1}
.vk-carousel .sc{font-size:13.5px;opacity:.92;z-index:1;max-width:72%}
.vk-carousel .nv{position:absolute;top:50%;transform:translateY(-50%);border:none;background:rgba(10,12,30,.42);color:#fff;width:35px;height:35px;border-radius:50%;cursor:pointer;font-size:17px;z-index:2}
.vk-carousel .nv:hover{background:rgba(10,12,30,.68)}
.vk-carousel .nv.l{left:13px}.vk-carousel .nv.r{right:13px}
.vk-carousel .dots{position:absolute;bottom:13px;left:0;right:0;display:flex;justify-content:center;gap:7px;z-index:2}
.vk-carousel .dots button{width:8px;height:8px;border-radius:50%;border:none;background:rgba(255,255,255,.45);cursor:pointer;padding:0;transition:.2s}
.vk-carousel .dots button.on{background:#fff;width:22px;border-radius:5px}
.vk-carousel .thumbs{position:absolute;bottom:13px;right:13px;display:flex;gap:6px;z-index:2}
.vk-carousel .tb{width:34px;height:22px;border-radius:5px;border:2px solid rgba(255,255,255,.5);cursor:pointer;padding:0}
.vk-carousel .tb.on{border-color:#fff}
.vk-carousel:focus-visible{outline:2px solid var(--vk-accent);outline-offset:2px}
.vk-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
