<template>
  <div class="vk-upload">
    <div v-if="appearance === 'dropzone'" class="vk-dropzone" :class="{ drag: draggingOver }"
      @dragover.prevent="draggingOver = true" @dragleave="draggingOver = false" @drop.prevent="onDrop"
      @click="$refs.inp.click()">
      <div class="ic">⇪</div>
      <strong>Drop files here or click to browse</strong>
      <span class="sub">{{ acceptLabel }}</span>
    </div>
    <v-button v-else appearance="secondary" :size="size" :disabled="disabled" :icon="icon" @click="$refs.inp.click()">
      {{ text }}
    </v-button>
    <input ref="inp" type="file" hidden :accept="accept" :multiple="multiple" @change="onPick">
    <div v-if="files.length && showPreview" class="vk-upload-grid">
      <div v-for="(f, i) in files" :key="i" class="thumb">
        <img v-if="previews[i]" :src="previews[i]" :alt="f.name">
        <span v-else class="ic2">📄</span>
        <span class="nm">{{ f.name }}</span>
        <button aria-label="Remove" @click="remove(i)">✕</button>
      </div>
    </div>
    <ul v-else-if="files.length" class="vk-upload-list">
      <li v-for="(f, i) in files" :key="i">
        <span class="nm">{{ f.name }}</span><span class="sz">{{ (f.size / 1024).toFixed(1) }} KB</span>
        <button aria-label="Remove" @click="remove(i)">✕</button>
      </li>
    </ul>
    <v-button v-if="files.length > 1" appearance="link" size="small" text="Clear all" @click="clearAll"></v-button>
    <div v-if="error" class="err" style="font-size:11.5px;color:var(--vk-danger)">{{ error }}</div>
  </div>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VFileUpload',
  components: { VButton },
  props: {
    appearance: { type: String, default: 'button' },  // button | dropzone
    text: { type: String, default: 'Upload files' },
    icon: { type: String, default: '📎' },
    accept: String,
    multiple: Boolean,
    maxAllowedFiles: { type: Number, default: 10 },
    maxAllowedSize: { type: Number, default: 10 * 1024 * 1024 },  // bytes
    showPreview: { type: Boolean, default: true },   // thumbnail previews for images
    size: { type: String, default: 'medium' },
    disabled: Boolean
  },
  emits: ['change'],
  data() { return { files: [], previews: [], draggingOver: false, error: '' } },
  computed: {
    acceptLabel() { return this.accept ? 'Accepted: ' + this.accept : 'Any file type' }
  },
  methods: {
    add(list) {
      this.error = ''
      const incoming = [...list]
      for (const f of incoming) {
        if (this.files.length >= this.maxAllowedFiles) { this.error = 'Maximum ' + this.maxAllowedFiles + ' files allowed.'; break }
        if (f.size > this.maxAllowedSize) { this.error = f.name + ' exceeds the size limit.'; continue }
        this.files.push(f)
        this.previews.push(f.type && f.type.startsWith('image/') ? URL.createObjectURL(f) : null)
      }
      this.$emit('change', this.files)
    },
    remove(i) {
      if (this.previews[i]) URL.revokeObjectURL(this.previews[i])
      this.files.splice(i, 1); this.previews.splice(i, 1)
      this.$emit('change', this.files)
    },
    clearAll() { this.files = []; this.previews.forEach(p => p && URL.revokeObjectURL(p)); this.previews = []; this.$emit('change', this.files) },
    onPick(e) { this.add(e.target.files); e.target.value = '' },
    onDrop(e) { this.draggingOver = false; this.add(e.dataTransfer.files) }
  }
};
</script>

<style>
.vk-upload{display:flex;flex-direction:column;gap:10px;min-width:260px}
.vk-dropzone{border:2px dashed var(--vk-line-2);border-radius:var(--vk-radius);padding:30px 20px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;transition:.15s;background:var(--vk-surface);text-align:center}
.vk-dropzone:hover,.vk-dropzone.drag{border-color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-dropzone .ic{font-size:26px}
.vk-dropzone .sub{font-size:12px;color:var(--vk-text-3)}
.vk-upload-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
.vk-upload-list li{display:flex;align-items:center;gap:10px;background:var(--vk-sunken);border-radius:var(--vk-radius-xs);padding:7px 11px;font-size:12.5px}
.vk-upload-list .nm{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vk-upload-list .sz{color:var(--vk-text-3);font-size:11.5px}
.vk-upload-list button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);padding:2px}
.vk-upload-list button:hover{color:var(--vk-danger)}
.vk-upload-grid{display:flex;flex-wrap:wrap;gap:9px}
.vk-upload-grid .thumb{position:relative;width:74px;display:flex;flex-direction:column;align-items:center;gap:3px}
.vk-upload-grid img{width:74px;height:74px;object-fit:cover;border-radius:var(--vk-radius-s);border:1.5px solid var(--vk-line)}
.vk-upload-grid .ic2{width:74px;height:74px;display:flex;align-items:center;justify-content:center;font-size:26px;background:var(--vk-sunken);border-radius:var(--vk-radius-s)}
.vk-upload-grid .nm{font-size:10px;color:var(--vk-text-3);max-width:74px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vk-upload-grid button{position:absolute;top:-6px;right:-6px;width:19px;height:19px;border-radius:50%;border:none;background:var(--vk-danger);color:#fff;font-size:10px;cursor:pointer}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
