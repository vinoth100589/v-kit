<template>
  <teleport to="body">
    <div v-if="modelValue" class="vk-cmdk-mask" @click.self="close">
      <div class="vk-cmdk" role="dialog" aria-modal="true" :aria-label="ariaLabel">
        <div class="hd">
          <span class="ic">⌘</span>
          <input ref="inp" v-model="query" class="q" :placeholder="placeholder" @keydown="onKeydown">
          <kbd class="esc">esc</kbd>
        </div>
        <div class="bd" ref="list">
          <template v-if="groups.length">
            <div v-for="g in groups" :key="g.name" class="grp">
              <div v-if="g.name" class="grp-lbl">{{ g.name }}</div>
              <div v-for="item in g.items" :key="item.id" class="it" role="option"
                :aria-selected="flat[kbIdx] === item" :class="{ kb: flat[kbIdx] === item }"
                @mouseenter="kbIdx = flat.indexOf(item)" @click="pick(item)">
                <span v-if="item.icon" class="icn">{{ item.icon }}</span>
                <span class="lbl" v-html="highlight(item.label)"></span>
                <kbd v-if="item.shortcut" class="sc">{{ item.shortcut }}</kbd>
              </div>
            </div>
          </template>
          <div v-else class="empty">{{ emptyText }}</div>
        </div>
        <div class="ft">
          <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
          <span><kbd>↵</kbd> select</span>
          <span><kbd>esc</kbd> close</span>
        </div>
      </div>
    </div>
  </teleport>
</template>

<script>
export default {
  name: 'VCommandPalette',
  props: {
    modelValue: Boolean,
    commands: { type: Array, default: () => [] },   // [{id, label, group?, icon?, shortcut?, keywords?}]
    placeholder: { type: String, default: 'Type a command or search…' },
    emptyText: { type: String, default: 'No matching commands' },
    closeOnSelect: { type: Boolean, default: true },
    hotkey: { type: Boolean, default: true },   // binds Cmd/Ctrl+K globally to toggle open
    ariaLabel: { type: String, default: 'Command palette' }
  },
  emits: ['update:modelValue', 'select', 'open', 'close'],
  data() { return { query: '', kbIdx: 0 } },
  computed: {
    matches() {
      const q = this.query.trim().toLowerCase()
      if (!q) return this.commands
      return this.commands.filter(c => {
        const hay = (c.label + ' ' + (c.keywords || []).join(' ')).toLowerCase()
        return hay.includes(q)
      })
    },
    groups() {
      const byGroup = new Map()
      for (const c of this.matches) {
        const g = c.group || ''
        if (!byGroup.has(g)) byGroup.set(g, [])
        byGroup.get(g).push(c)
      }
      return [...byGroup.entries()].map(([name, items]) => ({ name, items }))
    },
    flat() { return this.matches }
  },
  watch: {
    modelValue(v) {
      if (v) { this.query = ''; this.kbIdx = 0; this.$nextTick(() => this.$refs.inp && this.$refs.inp.focus()) }
    },
    query() { this.kbIdx = 0 }
  },
  mounted() {
    if (this.hotkey) {
      this.__hk = (e) => {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); this.toggle() }
        else if (e.key === 'Escape' && this.modelValue) this.close()
      }
      document.addEventListener('keydown', this.__hk)
    }
  },
  unmounted() { if (this.__hk) document.removeEventListener('keydown', this.__hk) },
  methods: {
    highlight(label) {
      const q = this.query.trim()
      if (!q) return label
      return label.replace(new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig'), '<mark>$1</mark>')
    },
    pick(item) {
      this.$emit('select', item)
      if (this.closeOnSelect) this.close()
    },
    open() { this.$emit('update:modelValue', true); this.$emit('open') },
    close() { this.$emit('update:modelValue', false); this.$emit('close') },
    toggle() { this.modelValue ? this.close() : this.open() },
    onKeydown(e) {
      const list = this.flat
      if (e.key === 'ArrowDown') { e.preventDefault(); this.kbIdx = list.length ? (this.kbIdx + 1) % list.length : 0 }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.kbIdx = list.length ? (this.kbIdx - 1 + list.length) % list.length : 0 }
      else if (e.key === 'Enter') { e.preventDefault(); if (list[this.kbIdx]) this.pick(list[this.kbIdx]) }
      else if (e.key === 'Escape') { e.preventDefault(); this.close() }
    }
  }
};
</script>

<style>
.vk-cmdk-mask{position:fixed;inset:0;background:color-mix(in srgb,var(--vk-shell) 55%,transparent);backdrop-filter:blur(2px);z-index:960;display:flex;align-items:flex-start;justify-content:center;padding:100px 18px}
.vk-cmdk{background:var(--vk-raised);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);width:100%;max-width:560px;display:flex;flex-direction:column;max-height:70vh;animation:vk-pop-in .16s ease;overflow:hidden}
.vk-cmdk .hd{display:flex;align-items:center;gap:11px;padding:14px 18px;border-bottom:1px solid var(--vk-line)}
.vk-cmdk .hd .ic{font-size:16px;color:var(--vk-text-3)}
.vk-cmdk .hd .q{flex:1;border:none;outline:none;background:none;font:inherit;font-size:15px;color:var(--vk-text)}
.vk-cmdk .hd .esc{opacity:.6}
.vk-cmdk kbd{background:var(--vk-sunken);border:1px solid var(--vk-line-2);border-radius:5px;padding:1px 6px;font-family:var(--vk-mono);font-size:10.5px;color:var(--vk-text-3)}
.vk-cmdk .bd{overflow-y:auto;padding:8px}
.vk-cmdk .grp-lbl{font-size:10.5px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--vk-text-3);padding:9px 10px 4px}
.vk-cmdk .it{display:flex;align-items:center;gap:10px;padding:9px 11px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13.5px}
.vk-cmdk .it:hover,.vk-cmdk .it.kb{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-cmdk .it .icn{font-size:15px}
.vk-cmdk .it .lbl{flex:1}
.vk-cmdk .it .lbl mark{background:none;color:inherit;font-weight:800;text-decoration:underline}
.vk-cmdk .it .sc{opacity:.7}
.vk-cmdk .empty{padding:28px;text-align:center;color:var(--vk-text-3);font-size:13px}
.vk-cmdk .ft{display:flex;gap:16px;padding:10px 16px;border-top:1px solid var(--vk-line);font-size:11px;color:var(--vk-text-3)}
.vk-cmdk .ft span{display:flex;align-items:center;gap:5px}

/* --- V-Kit shared styles (tokens + 4 themes + pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
