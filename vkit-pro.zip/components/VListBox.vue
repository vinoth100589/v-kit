<template>
  <div class="vk-listbox">
    <div v-if="search" class="vk-ddl-search" style="padding:9px">
      <input class="vk-input vk-input--sm" v-model="q" placeholder="Filter items…">
    </div>
    <div v-if="selectAll && multiple" class="vk-lb-all" @click="toggleAll">
      <span class="vk-menu-chk">{{ allOn ? '✓' : '' }}</span> Select all
    </div>
    <ul class="vk-list" role="listbox" :aria-multiselectable="multiple" :style="{ maxHeight: height }" @keydown="onKeydown">
      <li v-for="o in filtered" :key="o.value" ref="items" role="option" :aria-selected="isSel(o)" :aria-disabled="o.disabled"
        :tabindex="o.disabled ? -1 : 0" :class="{ sel: isSel(o), dis: o.disabled }"
        @click="pick(o)" @keydown.enter="pick(o)" @keydown.space.prevent="pick(o)">
        <span v-if="multiple" class="vk-menu-chk">{{ isSel(o) ? '✓' : '' }}</span>
        <span v-if="o.icon">{{ o.icon }}</span>{{ o.text }}
      </li>
      <li v-if="!filtered.length" class="vk-noresult">{{ emptyText }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'VListBox',
  props: {
    data: { type: Array, default: () => [] },
    modelValue: { type: [String, Number, Array], default: null },
    multiple: Boolean,
    search: Boolean,
    selectAll: Boolean,
    emptyText: { type: String, default: 'No matching items' },
    height: { type: String, default: '240px' }
  },
  emits: ['update:modelValue', 'select', 'deselect'],
  data() { return { q: '' } },
  computed: {
    norm() { return this.data.map(o => typeof o === 'object' ? o : { text: String(o), value: o }) },
    filtered() {
      const q = this.q.trim().toLowerCase()
      return q ? this.norm.filter(o => o.text.toLowerCase().includes(q)) : this.norm
    },
    allOn() { return Array.isArray(this.modelValue) && this.norm.every(o => this.modelValue.includes(o.value)) }
  },
  methods: {
    isSel(o) {
      return this.multiple ? Array.isArray(this.modelValue) && this.modelValue.includes(o.value) : this.modelValue === o.value
    },
    pick(o) {
      if (o.disabled) return
      if (!this.multiple) { this.$emit('update:modelValue', o.value); this.$emit('select', o); return }
      const cur = Array.isArray(this.modelValue) ? [...this.modelValue] : []
      const at = cur.indexOf(o.value)
      if (at > -1) { cur.splice(at, 1); this.$emit('deselect', o) } else { cur.push(o.value); this.$emit('select', o) }
      this.$emit('update:modelValue', cur)
    },
    toggleAll() {
      this.$emit('update:modelValue', this.allOn ? [] : this.norm.map(o => o.value))
    },
    onKeydown(e) {
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return
      const focusables = this.$refs.items || []
      const curIdx = focusables.findIndex(el => el === document.activeElement)
      e.preventDefault()
      let next = curIdx + (e.key === 'ArrowDown' ? 1 : -1)
      if (next < 0) next = focusables.length - 1
      if (next >= focusables.length) next = 0
      focusables[next] && focusables[next].focus()
    }
  }
};
</script>

<style>
.vk-listbox{border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);background:var(--vk-surface);min-width:250px;overflow:hidden}
.vk-lb-all{display:flex;align-items:center;gap:9px;padding:9px 16px;border-bottom:1px solid var(--vk-line);font-size:12.5px;font-weight:650;cursor:pointer;color:var(--vk-text-2)}
.vk-lb-all:hover{color:var(--vk-accent)}
.vk-listbox .vk-list li:focus-visible{outline:none;box-shadow:inset 0 0 0 2px var(--vk-accent)}
.vk-ddl-search{padding:9px 9px 3px}
.vk-menu-chk{width:14px;color:var(--vk-accent);font-weight:700}

/* --- V-Kit shared styles (tokens + 4 themes + field, pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}

.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
