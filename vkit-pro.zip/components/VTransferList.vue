<template>
  <div class="vk-transfer" :class="'vk-transfer--' + sz">
    <div class="vk-transfer-pane">
      <div class="hd">
        <label>
          <input type="checkbox" :checked="allChecked('left')" :indeterminate.prop="someChecked('left')"
            @change="toggleAll('left', $event.target.checked)">
          {{ titles[0] }}
        </label>
        <span class="cnt">{{ leftSel.length }}/{{ leftItems.length }}</span>
      </div>
      <input v-if="searchable" class="vk-input vk-input--sm srch" v-model="leftQuery" :placeholder="searchPlaceholder">
      <div class="list" role="listbox" :aria-label="titles[0]" :aria-multiselectable="true"
        :style="{ maxHeight: height }" @keydown="onKeydown($event, 'left')">
        <div v-for="it in filteredLeft" :key="it.value" ref="leftItems" class="it"
          :class="{ dis: it.disabled, on: leftSel.includes(it.value) }" :tabindex="it.disabled ? -1 : 0"
          role="option" :aria-selected="leftSel.includes(it.value)" :aria-disabled="it.disabled"
          @click="!it.disabled && toggleSel('left', it.value)"
          @dblclick="!it.disabled && moveOne(it.value, 'right')"
          @keydown.enter="!it.disabled && toggleSel('left', it.value)"
          @keydown.space.prevent="!it.disabled && toggleSel('left', it.value)">
          <input type="checkbox" tabindex="-1" :checked="leftSel.includes(it.value)" :disabled="it.disabled" @click.stop>
          <span v-if="it.icon" class="icn">{{ it.icon }}</span>
          <span class="lbl">{{ it.label }}</span>
        </div>
        <div v-if="!filteredLeft.length" class="empty">{{ emptyText }}</div>
      </div>
    </div>

    <div class="vk-transfer-ctl">
      <v-button appearance="secondary" size="small" :disabled="!leftSel.length" aria-label="Move selected to right"
        @click="moveSelected('right')">›</v-button>
      <v-button appearance="secondary" size="small" :disabled="!rightSel.length" aria-label="Move selected to left"
        @click="moveSelected('left')">‹</v-button>
    </div>

    <div class="vk-transfer-pane">
      <div class="hd">
        <label>
          <input type="checkbox" :checked="allChecked('right')" :indeterminate.prop="someChecked('right')"
            @change="toggleAll('right', $event.target.checked)">
          {{ titles[1] }}
        </label>
        <span class="cnt">{{ rightSel.length }}/{{ rightItems.length }}</span>
      </div>
      <input v-if="searchable" class="vk-input vk-input--sm srch" v-model="rightQuery" :placeholder="searchPlaceholder">
      <div class="list" role="listbox" :aria-label="titles[1]" :aria-multiselectable="true"
        :style="{ maxHeight: height }" @keydown="onKeydown($event, 'right')">
        <div v-for="it in filteredRight" :key="it.value" ref="rightItems" class="it"
          :class="{ dis: it.disabled, on: rightSel.includes(it.value) }" :tabindex="it.disabled ? -1 : 0"
          role="option" :aria-selected="rightSel.includes(it.value)" :aria-disabled="it.disabled"
          @click="!it.disabled && toggleSel('right', it.value)"
          @dblclick="!it.disabled && moveOne(it.value, 'left')"
          @keydown.enter="!it.disabled && toggleSel('right', it.value)"
          @keydown.space.prevent="!it.disabled && toggleSel('right', it.value)">
          <input type="checkbox" tabindex="-1" :checked="rightSel.includes(it.value)" :disabled="it.disabled" @click.stop>
          <span v-if="it.icon" class="icn">{{ it.icon }}</span>
          <span class="lbl">{{ it.label }}</span>
        </div>
        <div v-if="!filteredRight.length" class="empty">{{ emptyText }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import VButton from './VButton.vue'
function sizeClass(size) {
  return { small: 'sm', medium: 'md', large: 'lg' }[size] || size || 'md'
}
export default {
  name: 'VTransferList',
  components: { VButton },
  props: {
    items: { type: Array, default: () => [] },          // [{value, label, icon?, disabled?}]
    modelValue: { type: Array, default: () => [] },       // values currently on the right/target side
    titles: { type: Array, default: () => ['Available', 'Selected'] },
    searchable: Boolean,
    searchPlaceholder: { type: String, default: 'Search…' },
    emptyText: { type: String, default: 'No items' },
    height: { type: String, default: '260px' },
    size: { type: String, default: 'medium' }
  },
  emits: ['update:modelValue', 'change'],
  data() { return { leftSel: [], rightSel: [], leftQuery: '', rightQuery: '' } },
  computed: {
    sz() { return sizeClass(this.size) },
    leftItems() { return this.items.filter(it => !this.modelValue.includes(it.value)) },
    rightItems() { return this.items.filter(it => this.modelValue.includes(it.value)) },
    filteredLeft() { return this.filter(this.leftItems, this.leftQuery) },
    filteredRight() { return this.filter(this.rightItems, this.rightQuery) }
  },
  watch: {
    leftItems(items) { this.leftSel = this.leftSel.filter(v => items.some(it => it.value === v)) },
    rightItems(items) { this.rightSel = this.rightSel.filter(v => items.some(it => it.value === v)) }
  },
  methods: {
    filter(list, q) {
      const s = q.trim().toLowerCase()
      if (!s) return list
      return list.filter(it => String(it.label).toLowerCase().includes(s))
    },
    toggleSel(side, value) {
      const key = side === 'left' ? 'leftSel' : 'rightSel'
      const at = this[key].indexOf(value)
      at > -1 ? this[key].splice(at, 1) : this[key].push(value)
    },
    allChecked(side) {
      const list = side === 'left' ? this.filteredLeft : this.filteredRight
      const sel = side === 'left' ? this.leftSel : this.rightSel
      return list.length > 0 && list.every(it => it.disabled || sel.includes(it.value))
    },
    someChecked(side) {
      const sel = side === 'left' ? this.leftSel : this.rightSel
      return sel.length > 0 && !this.allChecked(side)
    },
    toggleAll(side, checked) {
      const list = side === 'left' ? this.filteredLeft : this.filteredRight
      const key = side === 'left' ? 'leftSel' : 'rightSel'
      this[key] = checked ? list.filter(it => !it.disabled).map(it => it.value) : []
    },
    moveSelected(dir) {
      if (dir === 'right') {
        const next = [...this.modelValue, ...this.leftSel]
        this.leftSel = []
        this.$emit('update:modelValue', next); this.$emit('change', next)
      } else {
        const remove = new Set(this.rightSel)
        const next = this.modelValue.filter(v => !remove.has(v))
        this.rightSel = []
        this.$emit('update:modelValue', next); this.$emit('change', next)
      }
    },
    moveOne(value, dir) {
      const next = dir === 'right' ? [...this.modelValue, value] : this.modelValue.filter(v => v !== value)
      this.leftSel = this.leftSel.filter(v => v !== value)
      this.rightSel = this.rightSel.filter(v => v !== value)
      this.$emit('update:modelValue', next); this.$emit('change', next)
    },
    onKeydown(e, side) {
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return
      const refs = side === 'left' ? this.$refs.leftItems : this.$refs.rightItems
      const focusables = refs || []
      const curIdx = focusables.findIndex(el => el === document.activeElement)
      e.preventDefault()
      let next = curIdx + (e.key === 'ArrowDown' ? 1 : -1)
      if (next < 0) next = focusables.length - 1
      if (next >= focusables.length) next = 0
      focusables[next] && focusables[next].focus()
    }
  }
};
</script>

<style>
.vk-transfer{display:flex;align-items:stretch;gap:10px}
.vk-transfer-pane{flex:1;min-width:0;border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);background:var(--vk-surface);display:flex;flex-direction:column;overflow:hidden}
.vk-transfer-pane .hd{display:flex;align-items:center;justify-content:space-between;padding:10px 13px;border-bottom:1px solid var(--vk-line);font-size:12.5px;font-weight:650;color:var(--vk-text-2)}
.vk-transfer-pane .hd label{display:flex;align-items:center;gap:8px;cursor:pointer}
.vk-transfer-pane .cnt{color:var(--vk-text-3);font-weight:600;font-size:11.5px}
.vk-transfer-pane .srch{margin:8px 10px 0;width:auto}
.vk-transfer-pane .list{overflow-y:auto;padding:6px}
.vk-transfer-pane .it{display:flex;align-items:center;gap:9px;padding:8px 9px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;user-select:none}
.vk-transfer-pane .it:hover{background:var(--vk-sunken)}
.vk-transfer-pane .it.on{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-transfer-pane .it.dis{opacity:.45;cursor:not-allowed}
.vk-transfer-pane .it .icn{font-size:14px}
.vk-transfer-pane .it .lbl{flex:1}
.vk-transfer-pane .empty{text-align:center;color:var(--vk-text-3);font-size:12.5px;padding:24px}
.vk-transfer-ctl{display:flex;flex-direction:column;justify-content:center;gap:7px}
.vk-transfer--sm .vk-transfer-pane .it{font-size:12px;padding:6px 8px}
.vk-transfer--lg .vk-transfer-pane .it{font-size:14px;padding:10px 11px}

/* --- V-Kit shared styles (tokens + 4 themes + field primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}
</style>
