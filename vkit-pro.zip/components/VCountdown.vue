<template>
  <div class="vk-count" :class="{ compact }">
    <template v-for="(u, i) in units" :key="u.label">
      <span class="cell"><strong>{{ String(u.v).padStart(2, '0') }}</strong><em v-if="!compact">{{ u.label }}</em></span>
      <span v-if="i < units.length - 1" class="sep">:</span>
    </template>
    <span v-if="finished && expiredText" class="expired">{{ expiredText }}</span>
  </div>
</template>

<script>
export default {
  name: 'VCountdown',
  props: {
    seconds: { type: Number, default: 0 },   // count down from N seconds…
    target: String,                          // …or to an ISO datetime ('2026-12-31T00:00:00')
    compact: Boolean,   // hides the day/hr/min/sec unit labels
    expiredText: String   // shown in place of the counter once it reaches zero
  },
  emits: ['finish', 'tick'],
  data() { return { left: 0, finished: false } },
  computed: {
    units() {
      const s = Math.max(0, this.left)
      return [
        { label: 'days', v: Math.floor(s / 86400) },
        { label: 'hrs', v: Math.floor(s / 3600) % 24 },
        { label: 'min', v: Math.floor(s / 60) % 60 },
        { label: 'sec', v: s % 60 }
      ].filter((u, i) => u.v > 0 || i > 0 || s >= 86400)
    }
  },
  mounted() {
    this.left = this.target
      ? Math.max(0, Math.floor((new Date(this.target) - Date.now()) / 1000))
      : this.seconds
    this._t = setInterval(() => {
      if (this.left <= 0) { clearInterval(this._t); this.finished = true; this.$emit('finish'); return }
      this.left--; this.$emit('tick', this.left)
    }, 1000)
  },
  unmounted() { clearInterval(this._t) }
};
</script>

<style>
.vk-count{display:inline-flex;align-items:center;gap:7px}
.vk-count .cell{display:flex;flex-direction:column;align-items:center;background:var(--vk-shell);color:#fff;border-radius:11px;padding:9px 13px;min-width:56px}
.vk-count.compact .cell{padding:7px 10px;min-width:auto}
.vk-count .cell strong{font-size:21px;font-family:var(--vk-mono);line-height:1.1}
.vk-count .cell em{font-style:normal;font-size:9.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--vk-shell-text)}
.vk-count .sep{font-size:19px;font-weight:800;color:var(--vk-text-3)}
.vk-count .expired{font-size:13px;font-weight:700;color:var(--vk-danger);margin-left:6px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
