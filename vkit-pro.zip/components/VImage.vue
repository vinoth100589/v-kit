<template>
  <div class="vk-img" :class="{ zoomable }" :style="{ width, height, borderRadius: rounded ? 'var(--vk-radius)' : '0' }"
    @click="zoomable && state === 'ok' && (zoomed = true)">
    <div v-if="state === 'loading'" class="ph shimmer"></div>
    <div v-else-if="state === 'error'" class="ph fail"><span>{{ fallbackIcon }}</span><em>{{ alt || 'Image unavailable' }}</em></div>
    <img v-show="state === 'ok'" :src="src" :alt="alt" :loading="lazy ? 'lazy' : 'eager'" @load="state = 'ok'" @error="state = 'error'">
    <span v-if="zoomable && state === 'ok'" class="zoomhint">🔍</span>
  </div>
  <teleport to="body">
    <div v-if="zoomed" class="vk-img-lightbox" @click="zoomed = false">
      <img :src="src" :alt="alt">
      <button aria-label="Close" @click.stop="zoomed = false">✕</button>
    </div>
  </teleport>
</template>

<script>
export default {
  name: 'VImage',
  props: {
    src: String,
    alt: String,
    width: { type: String, default: '100%' },
    height: { type: String, default: '180px' },
    rounded: { type: Boolean, default: true },
    lazy: { type: Boolean, default: true },
    zoomable: Boolean,   // click to open a full-size lightbox overlay
    fallbackIcon: { type: String, default: '🖼' }
  },
  data() { return { state: this.src ? 'loading' : 'error', zoomed: false } },
  watch: { src(v) { this.state = v ? 'loading' : 'error' } }
};
</script>

<style>
.vk-img{position:relative;overflow:hidden;background:var(--vk-sunken)}
.vk-img.zoomable{cursor:zoom-in}
.vk-img img{width:100%;height:100%;object-fit:cover;display:block}
.vk-img .ph{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;color:var(--vk-text-3)}
.vk-img .ph span{font-size:30px;opacity:.6}
.vk-img .ph em{font-style:normal;font-size:11.5px}
.vk-img .shimmer{background:linear-gradient(100deg,var(--vk-sunken) 35%,var(--vk-line) 50%,var(--vk-sunken) 65%);background-size:220% 100%;animation:vk-img-sh 1.3s infinite}
@keyframes vk-img-sh{from{background-position:200% 0}to{background-position:-40% 0}}
.vk-img .zoomhint{position:absolute;right:8px;bottom:8px;background:rgba(0,0,0,.5);color:#fff;border-radius:6px;padding:3px 6px;font-size:11px;opacity:0;transition:.15s}
.vk-img.zoomable:hover .zoomhint{opacity:1}
.vk-img-lightbox{position:fixed;inset:0;background:rgba(6,8,20,.85);z-index:980;display:flex;align-items:center;justify-content:center;cursor:zoom-out;padding:30px}
.vk-img-lightbox img{max-width:92vw;max-height:92vh;object-fit:contain;border-radius:10px}
.vk-img-lightbox button{position:absolute;top:20px;right:24px;border:none;background:rgba(255,255,255,.15);color:#fff;width:36px;height:36px;border-radius:50%;font-size:15px;cursor:pointer}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
