<template>
  <div v-if="visible" ref="root" class="vk-pop vk-menu" :class="'vk-menu--' + placement" :style="{ minWidth: width }"
    role="menu" tabindex="-1" @keydown="onKeydown">
    <div v-if="searchable" class="vk-menu-search">
      <input class="vk-input vk-input--sm" v-model="q" placeholder="Filter…" @click.stop>
    </div>
    <template v-for="(it, i) in filteredItems" :key="i">
      <div v-if="it.divider" class="vk-menu-div" role="separator"></div>
      <div v-else class="vk-menu-it" :class="{ dis: it.disabled, haschild: it.items, kb: kbIdx === i }"
        role="menuitem" :aria-disabled="it.disabled" tabindex="-1"
        @click.stop="pick(it)" @mouseenter="hoverIdx = i; kbIdx = i" @mouseleave="hoverIdx = -1">
        <span v-if="it.type === 'checkbox' || it.type === 'radio'" class="vk-menu-chk">{{ it.checked ? '✓' : '' }}</span>
        <span v-if="it.icon" class="vk-menu-ic">{{ it.icon }}</span>
        <span class="lbl">{{ it.label }}</span>
        <span v-if="it.shortcut" class="sc">{{ it.shortcut }}</span>
        <span v-if="it.items" class="car">›</span>
        <div v-if="it.items && hoverIdx === i" class="vk-pop vk-menu vk-menu-sub">
          <div v-for="(s, j) in it.items" :key="j" class="vk-menu-it" role="menuitem" :aria-disabled="s.disabled" :class="{ dis: s.disabled }" @click.stop="pick(s)">
            <span v-if="s.icon" class="vk-menu-ic">{{ s.icon }}</span>
            <span class="lbl">{{ s.label }}</span>
          </div>
        </div>
      </div>
    </template>
    <div v-if="!filteredItems.length" class="vk-noresult" style="padding:12px 14px">No matches</div>
  </div>
</template>

<script>
export default {
  name: 'VMenu',
  props: {
    items: { type: Array, default: () => [] },  // [{label, icon?, type?, checked?, shortcut?, disabled?, items?, divider?}]
    visible: Boolean,
    width: { type: String, default: '200px' },
    placement: { type: String, default: 'left' },   // left | right (horizontal alignment of the panel)
    searchable: Boolean
  },
  emits: ['itemclick', 'update:visible', 'hide'],
  data() { return { hoverIdx: -1, kbIdx: -1, q: '' } },
  computed: {
    filteredItems() {
      const q = this.q.trim().toLowerCase()
      if (!q) return this.items
      return this.items.filter(it => it.divider || (it.label || '').toLowerCase().includes(q))
    }
  },
  watch: {
    visible(v) {
      if (v) { this.kbIdx = -1; this.$nextTick(() => this.$refs.root && this.$refs.root.focus()) }
    }
  },
  methods: {
    pick(it) {
      if (it.disabled || it.items) return
      this.$emit('itemclick', it)
      this.$emit('update:visible', false)
      this.$emit('hide')
    },
    show() { this.$emit('update:visible', true) },
    hide() { this.$emit('update:visible', false) },
    onKeydown(e) {
      const selectable = this.filteredItems.map((it, i) => ({ it, i })).filter(x => !x.it.divider)
      if (!selectable.length && e.key !== 'Escape') return
      const move = (dir) => {
        const pos = selectable.findIndex(x => x.i === this.kbIdx)
        let next = pos + dir
        if (next < 0) next = selectable.length - 1
        if (next >= selectable.length) next = 0
        this.kbIdx = selectable[next].i
      }
      if (e.key === 'ArrowDown') { e.preventDefault(); move(1) }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1) }
      else if (e.key === 'Home') { e.preventDefault(); this.kbIdx = selectable[0]?.i ?? -1 }
      else if (e.key === 'End') { e.preventDefault(); this.kbIdx = selectable[selectable.length - 1]?.i ?? -1 }
      else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        const it = this.filteredItems[this.kbIdx]
        if (it) this.pick(it)
      } else if (e.key === 'Escape') { e.preventDefault(); this.hide() }
    }
  }
};
</script>

<style>
.vk-menu{padding:7px;top:calc(100% + 6px);left:0;outline:none}
.vk-menu--right{left:auto;right:0}
.vk-menu-search{padding:2px 2px 7px}
.vk-menu-it{display:flex;align-items:center;gap:9px;padding:8px 11px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;position:relative}
.vk-menu-it:hover,.vk-menu-it.kb{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-menu-it.dis{opacity:.4;cursor:not-allowed}
.vk-menu-it .lbl{flex:1;white-space:nowrap}
.vk-menu-it .sc{font-size:11px;color:var(--vk-text-3)}
.vk-menu-it .car{color:var(--vk-text-3)}
.vk-menu-chk{width:14px;color:var(--vk-accent);font-weight:700}
.vk-menu-div{height:1px;background:var(--vk-line);margin:6px 5px}
.vk-menu-sub{left:100%;top:-7px}

/* --- V-Kit shared styles (tokens + 4 themes + field, pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}

.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
