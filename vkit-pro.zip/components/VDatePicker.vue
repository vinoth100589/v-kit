<template>
  <div class="vk-dp" style="position:relative;display:inline-block">
    <slot name="trigger" :open="openPicker" :value="modelValue">
      <v-button appearance="secondary" @click="openPicker">📅 {{ modelValue || placeholder }}</v-button>
    </slot>
    <div v-if="isOpen" class="vk-pop vk-pop--under vk-cal" style="width:280px">
      <div v-if="presets.length" class="vk-dp-presets">
        <button v-for="p in presets" :key="p.label" @click="pick(p.value)">{{ p.label }}</button>
      </div>
      <v-calendar-core :model-value="modelValue" :min="min" :max="max" :week-starts-on="weekStartsOn"
        :disabled-dates="disabledDates" @pick="pick"></v-calendar-core>
      <div v-if="commandBar" class="cmd">
        <v-button appearance="link" size="small" :text="todayButtonLabel" @click="pick(today)"></v-button>
        <span>
          <v-button v-if="clearButton" appearance="link" size="small" :text="clearButtonLabel" @click="clear"></v-button>
          <v-button appearance="link" size="small" :text="cancelButtonLabel" @click="close"></v-button>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import VButton from './VButton.vue'
import VCalendarCore, { fmt } from './VCalendarCore.vue'
const clickOutside = {
  mounted() {
    this.__vkOut = (e) => { if (this.$el && !this.$el.contains(e.target)) this.onClickOutside && this.onClickOutside(e) }
    document.addEventListener('mousedown', this.__vkOut)
  },
  unmounted() { document.removeEventListener('mousedown', this.__vkOut) }
}
export default {
  name: 'VDatePicker',
  components: { VCalendarCore, VButton },
  mixins: [clickOutside],
  props: {
    modelValue: String, min: String, max: String,
    placeholder: { type: String, default: 'Pick a date' },
    commandBar: { type: Boolean, default: true },
    clearButton: { type: Boolean, default: true },
    closeOnDateSelect: { type: Boolean, default: true },
    weekStartsOn: { type: Number, default: 0 },
    disabledDates: { type: Function, default: null },
    presets: { type: Array, default: () => [] },   // [{label, value}] quick-pick shortcuts above the calendar
    todayButtonLabel: { type: String, default: 'Today' },
    clearButtonLabel: { type: String, default: 'Clear' },
    cancelButtonLabel: { type: String, default: 'Cancel' }
  },
  emits: ['update:modelValue', 'change', 'open', 'close', 'clear'],
  data() { return { isOpen: false } },
  computed: { today() { return fmt(new Date()) } },
  methods: {
    onClickOutside() { if (this.isOpen) this.close() },
    openPicker() { this.isOpen = true; this.$emit('open') },   // .open() per spec: must be called explicitly
    open() { this.openPicker() },
    close() { this.isOpen = false; this.$emit('close') },
    pick(s) {
      this.$emit('update:modelValue', s); this.$emit('change', s)
      if (this.closeOnDateSelect) this.close()
    },
    clear() { this.$emit('update:modelValue', ''); this.$emit('clear'); this.close() }
  }
};
</script>

<style>
.vk-dp-presets{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:11px;border-bottom:1px dashed var(--vk-line);padding-bottom:11px}
.vk-dp-presets button{border:1.5px solid var(--vk-line-2);background:var(--vk-surface);border-radius:999px;padding:4px 12px;font-size:11.5px;font-weight:650;cursor:pointer;color:var(--vk-text-2);font-family:inherit}
.vk-dp-presets button:hover{border-color:var(--vk-accent);color:var(--vk-accent)}

/* --- V-Kit shared styles (tokens + 4 themes + pop, cal primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}

.vk-cal{padding:14px;width:270px}
.vk-cal .hd{display:flex;align-items:center;justify-content:space-between;font-weight:700;font-size:13px;margin-bottom:10px}
.vk-cal .hd button{border:none;background:var(--vk-sunken);width:27px;height:27px;border-radius:8px;cursor:pointer;color:var(--vk-text-2);font-size:14px;font-family:inherit}
.vk-cal .hd button:hover{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-cal .wk{display:grid;grid-template-columns:repeat(7,1fr);font-size:10px;font-weight:700;letter-spacing:.08em;color:var(--vk-text-3);text-align:center;margin-bottom:5px;text-transform:uppercase}
.vk-cal .gr{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}
.vk-cal .dy{border:none;background:none;height:31px;border-radius:9px;cursor:pointer;font-size:12.5px;color:var(--vk-text);font-family:inherit;position:relative}
.vk-cal .dy:hover:not(:disabled){background:var(--vk-sunken)}
.vk-cal .dy.out{color:var(--vk-text-3);opacity:.5}
.vk-cal .dy.today::after{content:"";position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:var(--vk-accent)}
.vk-cal .dy.sel{background:var(--vk-grad);color:var(--vk-on-accent);font-weight:700}
.vk-cal .dy.inrange{background:var(--vk-accent-soft);border-radius:0}
.vk-cal .dy:disabled{opacity:.22;cursor:not-allowed}
.vk-cal .cmd{display:flex;justify-content:space-between;gap:8px;margin-top:10px;border-top:1px dashed var(--vk-line);padding-top:10px}
</style>
