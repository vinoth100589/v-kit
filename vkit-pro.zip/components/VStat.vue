<template>
  <div class="vk-stat">
    <div v-if="loading" class="vk-stat-skel">
      <div class="sk" style="width:50%;height:10px"></div>
      <div class="sk" style="width:70%;height:24px;margin:8px 0"></div>
      <div class="sk" style="width:40%;height:10px"></div>
    </div>
    <template v-else>
      <div class="row1"><span class="lb">{{ label }}</span><span v-if="icon" class="ic">{{ icon }}</span></div>
      <div class="val">{{ value }}</div>
      <div v-if="delta !== null" class="dl" :class="deltaClass">
        {{ delta > 0 ? '▲' : delta < 0 ? '▼' : '—' }} {{ Math.abs(delta) }}{{ deltaSuffix }}
        <span v-if="caption" class="cap">{{ caption }}</span>
      </div>
    </template>
  </div>
</template>

<script>
export default {
  name: 'VStat',
  props: {
    label: { type: String, required: true },
    value: { type: [String, Number], required: true },
    icon: String,
    delta: { type: Number, default: null },
    deltaSuffix: { type: String, default: '%' },
    caption: String,
    invertColors: Boolean,   // for metrics where down is good
    loading: Boolean
  },
  computed: {
    deltaClass() {
      if (this.delta === 0 || this.delta === null) return 'flat'
      const up = this.delta > 0
      return (this.invertColors ? !up : up) ? 'good' : 'bad'
    }
  }
};
</script>

<style>
.vk-stat{background:var(--vk-surface);border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);padding:17px 19px;min-width:190px}
.vk-stat .row1{display:flex;justify-content:space-between;align-items:center}
.vk-stat .lb{font-size:11px;font-weight:800;letter-spacing:.09em;text-transform:uppercase;color:var(--vk-text-3)}
.vk-stat .ic{font-size:16px}
.vk-stat .val{font-size:28px;font-weight:800;margin:6px 0 4px;background:var(--vk-grad);-webkit-background-clip:text;background-clip:text;color:transparent;display:inline-block}
.vk-stat .dl{font-size:12px;font-weight:700}
.vk-stat .dl.good{color:var(--vk-success)}
.vk-stat .dl.bad{color:var(--vk-danger)}
.vk-stat .dl.flat{color:var(--vk-text-3)}
.vk-stat .cap{color:var(--vk-text-3);font-weight:500;margin-left:5px}
.vk-stat-skel .sk{background:linear-gradient(100deg,var(--vk-sunken) 35%,var(--vk-line) 50%,var(--vk-sunken) 65%);background-size:220% 100%;animation:vk-shimmer 1.3s infinite;border-radius:6px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
