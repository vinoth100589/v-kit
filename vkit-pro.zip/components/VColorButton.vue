<template>
  <div style="position:relative;display:inline-block">
    <button class="vk-clrbtn" :class="'vk-clrbtn--' + sz" :disabled="disabled" :aria-label="'Color: ' + modelValue" @click="open = !open">
      <span class="chip" :style="{ background: modelValue }"></span>
    </button>
    <v-color-picker :model-value="modelValue" :visible="open" :colors="colors" :disabled="disabled"
      :advanced-picker="advancedPicker" :show-alpha="showAlpha"
      @update:model-value="$emit('update:modelValue', $event); $emit('change', $event)"
      @update:visible="open = $event"></v-color-picker>
  </div>
</template>

<script>
import VColorPicker from './VColorPicker.vue'
function sizeClass(size) {
  return { small: 'sm', medium: 'md', large: 'lg' }[size] || size || 'md'
}
const clickOutside = {
  mounted() {
    this.__vkOut = (e) => { if (this.$el && !this.$el.contains(e.target)) this.onClickOutside && this.onClickOutside(e) }
    document.addEventListener('mousedown', this.__vkOut)
  },
  unmounted() { document.removeEventListener('mousedown', this.__vkOut) }
}
export default {
  name: 'VColorButton',
  components: { VColorPicker },
  mixins: [clickOutside],
  props: {
    modelValue: { type: String, default: '#7c3aed' },
    colors: { type: Array, default: () => [] },
    advancedPicker: Boolean,   // adds a "More…" link that expands an inline hue/saturation/format picker
    showAlpha: Boolean,        // adds an alpha slider in advanced mode
    size: { type: String, default: 'medium' },
    disabled: Boolean
  },
  emits: ['update:modelValue', 'change'],
  data() { return { open: false } },
  computed: { sz() { return sizeClass(this.size) } },
  methods: { onClickOutside() { this.open = false } }
};
</script>

<style>
.vk-clrbtn{width:38px;height:38px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);background:var(--vk-surface);cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0}
.vk-clrbtn:hover{border-color:var(--vk-accent)}
.vk-clrbtn:disabled{opacity:.45;cursor:not-allowed}
.vk-clrbtn .chip{width:24px;height:24px;border-radius:7px;border:1px solid rgba(0,0,0,.12)}
.vk-clrbtn--sm{width:30px;height:30px}
.vk-clrbtn--sm .chip{width:18px;height:18px}
.vk-clrbtn--lg{width:46px;height:46px}
.vk-clrbtn--lg .chip{width:30px;height:30px}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
