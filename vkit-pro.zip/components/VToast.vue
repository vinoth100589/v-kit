<template>
  <div class="vk-toasts" :class="'vk-toasts--' + position">
    <transition-group name="vk-toast">
      <div v-for="t in stack" :key="t.id" class="vk-toast" :class="'vk-toast--' + t.type"
        @mouseenter="pauseOnHover && pause(t)" @mouseleave="pauseOnHover && resume(t)">
        <span class="ic">{{ { info: 'ℹ', success: '✓', warning: '⚠', error: '✕' }[t.type] }}</span>
        <div class="bd">
          <strong>{{ t.title || t.type }}</strong>
          <div v-if="t.message">{{ t.message }}</div>
        </div>
        <button v-if="t.action" class="act" @click="t.action.onClick && t.action.onClick(); dismiss(t.id)">{{ t.action.text }}</button>
        <button aria-label="Dismiss" @click="dismiss(t.id)">✕</button>
      </div>
    </transition-group>
  </div>
</template>

<script>
export default {
  name: 'VToast',
  props: {
    duration: { type: Number, default: 3500 },   // ms; 0 keeps toasts open
    position: { type: String, default: 'top-right' },   // top-right | top-left | bottom-right | bottom-left
    pauseOnHover: { type: Boolean, default: true }   // pauses the auto-dismiss timer while the pointer is over a toast
  },
  emits: ['show', 'hide'],
  data() { return { stack: [], seq: 0, timers: {} } },
  beforeUnmount() { Object.values(this.timers).forEach(id => clearTimeout(id)) },
  methods: {
    show(opts) {
      const t = Object.assign({ id: ++this.seq, type: 'info', message: '' },
        typeof opts === 'string' ? { message: opts } : opts)
      const dur = t.duration !== undefined ? t.duration : this.duration
      t._remaining = dur
      this.stack.push(t)
      this.$emit('show', t)
      this.arm(t)
      return t.id
    },
    arm(t) {
      if (!(t._remaining > 0)) return
      t._startedAt = Date.now()
      this.timers[t.id] = setTimeout(() => this.dismiss(t.id), t._remaining)
    },
    pause(t) {
      if (!this.timers[t.id]) return
      clearTimeout(this.timers[t.id])
      delete this.timers[t.id]
      t._remaining -= Date.now() - t._startedAt
    },
    resume(t) { this.arm(t) },
    dismiss(id) {
      if (this.timers[id]) { clearTimeout(this.timers[id]); delete this.timers[id] }
      const i = this.stack.findIndex(t => t.id === id)
      if (i > -1) { this.$emit('hide', this.stack[i]); this.stack.splice(i, 1) }
    }
  }
};
</script>

<style>
.vk-toasts{position:fixed;z-index:990;display:flex;flex-direction:column;gap:10px;width:330px}
.vk-toasts--top-right{top:18px;right:18px}
.vk-toasts--top-left{top:18px;left:18px}
.vk-toasts--bottom-right{bottom:18px;right:18px;flex-direction:column-reverse}
.vk-toasts--bottom-left{bottom:18px;left:18px;flex-direction:column-reverse}
.vk-toast{display:flex;gap:11px;align-items:flex-start;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius-s);padding:13px 15px;box-shadow:var(--vk-shadow-pop);font-size:13px}
.vk-toast .ic{font-weight:800}
.vk-toast .bd{flex:1}
.vk-toast .bd strong{text-transform:capitalize}
.vk-toast .act{border:none;background:none;cursor:pointer;color:var(--vk-accent);font-weight:750;padding:0;font-size:12.5px;text-decoration:underline}
.vk-toast button:not(.act){border:none;background:none;cursor:pointer;color:var(--vk-text-3);padding:0}
.vk-toast--info .ic{color:var(--vk-info)}
.vk-toast--success .ic{color:var(--vk-success)}
.vk-toast--warning .ic{color:var(--vk-warning)}
.vk-toast--error .ic{color:var(--vk-danger)}
.vk-toast-enter-active,.vk-toast-leave-active{transition:all .25s}
.vk-toast-enter-from,.vk-toast-leave-to{opacity:0;transform:translateX(16px)}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
