<template>
  <div class="vk-field">
    <label v-if="label">{{ label }}</label>
    <div class="vk-input vk-selbtn vk-selbtn--haswrap" :class="{ 'vk-field--dis': disabled }">
      <button type="button" class="vk-ds-hit" :disabled="disabled" @click="toggle" aria-haspopup="listbox" :aria-expanded="open">
        <span :class="{ ph: !display }">{{ display || placeholder }}</span>
      </button>
      <button v-if="clearable && modelValue" type="button" class="vk-ds-clear" aria-label="Clear" @click.stop="clear">✕</button>
      <span class="caret" :class="{ up: open }">▾</span>
    </div>
    <div v-if="open" class="vk-pop vk-pop--under vk-ds-pop" style="width:280px" @keydown="onKeydown">
      <template v-if="mode === 'presets'">
        <ul class="vk-list" role="listbox">
          <li v-for="(p, i) in presetList" :key="p.label" role="option" :aria-selected="modelValue === p.value"
            :class="{ sel: modelValue === p.value, kb: kbIdx === i }" @mouseenter="kbIdx = i" @click="pick(p)">{{ p.label }}</li>
          <li role="option" :class="{ kb: kbIdx === presetList.length }" @mouseenter="kbIdx = presetList.length" @click="showCustom">Custom date…</li>
        </ul>
      </template>
      <template v-else>
        <div class="vk-ds-customhead">
          <button type="button" class="vk-ds-back" @click="mode = 'presets'">‹ Presets</button>
        </div>
        <v-calendar-core :model-value="modelValue" :min="min" :max="max" :week-starts-on="weekStartsOn"
          :disabled-dates="disabledDates" @pick="pickCustom"></v-calendar-core>
      </template>
    </div>
  </div>
</template>

<script>
import VCalendarCore, { fmt } from './VCalendarCore.vue'
const clickOutside = {
  mounted() {
    this.__vkOut = (e) => { if (this.$el && !this.$el.contains(e.target)) this.onClickOutside && this.onClickOutside(e) }
    document.addEventListener('mousedown', this.__vkOut)
  },
  unmounted() { document.removeEventListener('mousedown', this.__vkOut) }
}
export default {
  name: 'VDateSelect',
  components: { VCalendarCore },
  mixins: [clickOutside],
  props: {
    modelValue: String,
    label: String,
    placeholder: { type: String, default: 'Select a date' },
    customPresets: { type: Array, default: null },   // override the default preset list: [{label, value}]
    min: String, max: String,
    weekStartsOn: { type: Number, default: 0 },
    disabledDates: { type: Function, default: null },
    clearable: Boolean,
    disabled: Boolean
  },
  emits: ['update:modelValue', 'change', 'open', 'close'],
  data() { return { open: false, mode: 'presets', kbIdx: -1 } },
  computed: {
    presetList() {
      if (this.customPresets) return this.customPresets
      const d = (n) => { const x = new Date(); x.setDate(x.getDate() + n); return fmt(x) }
      return [
        { label: 'Today', value: d(0) }, { label: 'Yesterday', value: d(-1) },
        { label: 'Tomorrow', value: d(1) }, { label: 'A week ago', value: d(-7) },
        { label: 'In a week', value: d(7) }
      ]
    },
    display() {
      const p = this.presetList.find(p => p.value === this.modelValue)
      return p ? p.label + ' · ' + p.value : this.modelValue
    }
  },
  methods: {
    onClickOutside() { if (this.open) { this.open = false; this.$emit('close') }; this.mode = 'presets' },
    toggle() {
      this.open = !this.open
      this.mode = 'presets'; this.kbIdx = -1
      this.$emit(this.open ? 'open' : 'close')
    },
    showCustom() { this.mode = 'custom' },
    pick(p) { this.$emit('update:modelValue', p.value); this.$emit('change', p.value); this.open = false; this.$emit('close') },
    pickCustom(s) { this.$emit('update:modelValue', s); this.$emit('change', s); this.open = false; this.mode = 'presets'; this.$emit('close') },
    clear() { this.$emit('update:modelValue', null); this.$emit('change', null) },
    onKeydown(e) {
      if (this.mode !== 'presets') { if (e.key === 'Escape') { this.mode = 'presets' }; return }
      const total = this.presetList.length + 1
      if (e.key === 'ArrowDown') { e.preventDefault(); this.kbIdx = this.kbIdx >= total - 1 ? 0 : this.kbIdx + 1 }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.kbIdx = this.kbIdx <= 0 ? total - 1 : this.kbIdx - 1 }
      else if (e.key === 'Enter') {
        e.preventDefault()
        if (this.kbIdx === this.presetList.length) this.showCustom()
        else if (this.presetList[this.kbIdx]) this.pick(this.presetList[this.kbIdx])
      } else if (e.key === 'Escape') { e.preventDefault(); this.open = false; this.$emit('close') }
    }
  }
};
</script>

<style>
.vk-selbtn{display:flex;align-items:center;justify-content:space-between;cursor:pointer;text-align:left;gap:10px}
.vk-selbtn .ph{color:var(--vk-text-3)}
.vk-selbtn .caret{font-size:10px;color:var(--vk-text-3);transition:.15s;flex:none}
.vk-selbtn .caret.up{transform:rotate(180deg)}
.vk-selbtn--haswrap{padding-right:10px}
.vk-ds-hit{flex:1;min-width:0;border:none;background:none;padding:0;margin:0;font:inherit;color:inherit;text-align:left;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vk-ds-hit:disabled{cursor:not-allowed}
.vk-ds-clear{border:none;background:var(--vk-sunken);color:var(--vk-text-3);width:18px;height:18px;border-radius:50%;font-size:10px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;flex:none}
.vk-ds-clear:hover{color:var(--vk-danger)}
.vk-ds-pop{padding:0}
.vk-ds-pop .vk-list{padding:7px}
.vk-ds-customhead{padding:9px 12px;border-bottom:1px solid var(--vk-line)}
.vk-ds-back{border:none;background:none;color:var(--vk-accent);font-family:inherit;font-size:12.5px;font-weight:650;cursor:pointer;padding:0}
.vk-ds-pop .vk-cal-core{padding:12px}

/* --- V-Kit shared styles (tokens + 4 themes + field, pop primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}

.vk-pop{position:absolute;z-index:900;background:var(--vk-raised);border:1px solid var(--vk-line);border-radius:var(--vk-radius);box-shadow:var(--vk-shadow-pop);animation:vk-pop-in .16s ease}
@keyframes vk-pop-in{from{opacity:0;transform:translateY(-5px) scale(.98)}to{opacity:1;transform:none}}
.vk-pop--under{top:calc(100% + 6px);left:0}
.vk-list{list-style:none;margin:0;padding:7px;max-height:260px;overflow:auto}
.vk-list li{padding:8px 12px;border-radius:var(--vk-radius-xs);cursor:pointer;font-size:13px;display:flex;align-items:center;gap:9px}
.vk-list li:hover,.vk-list li.focus{background:var(--vk-accent-soft);color:var(--vk-accent)}
.vk-list li.sel{font-weight:650;color:var(--vk-accent)}
.vk-list li.dis{opacity:.4;cursor:not-allowed}
.vk-list .vk-noresult{color:var(--vk-text-3);cursor:default;justify-content:center}
.vk-list .vk-noresult:hover{background:none;color:var(--vk-text-3)}
</style>
