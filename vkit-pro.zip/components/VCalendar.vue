<template>
  <div class="vk-bigcal">
    <div class="hd">
      <strong>{{ monthLabel }}</strong>
      <span>
        <v-button appearance="secondary" size="small" text="‹" aria-label="Previous month" @click="move(-1)"></v-button>
        <v-button appearance="secondary" size="small" text="Today" @click="goToday"></v-button>
        <v-button appearance="secondary" size="small" text="›" aria-label="Next month" @click="move(1)"></v-button>
      </span>
    </div>
    <div class="wk"><span v-for="w in ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']" :key="w">{{ w }}</span></div>
    <div class="gr">
      <div v-for="c in grid" :key="c.key" class="cell" :class="{ out: c.out, today: c.s === todayStr, sel: inSelected(c.s) }"
        @click="onCellClick(c.s)">
        <span class="d">{{ c.d.getDate() }}</span>
        <span v-for="(e, j) in eventsOn(c.s)" :key="j" class="ev" :style="{ background: e.color || 'var(--vk-accent)' }">{{ e.label }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import VButton from './VButton.vue'
export default {
  name: 'VCalendar',
  components: { VButton },
  props: {
    events: { type: Array, default: () => [] },   // [{date:'YYYY-MM-DD', label, color?}]
    selectable: Boolean,   // clicking days highlights them and builds a selection array
    selected: { type: Array, default: () => [] }   // v-model:selected — selected date strings
  },
  emits: ['datecellclick', 'monthchange', 'update:selected'],
  data() { const d = new Date(); return { vy: d.getFullYear(), vm: d.getMonth() } },
  computed: {
    monthLabel() { return new Date(this.vy, this.vm, 1).toLocaleString('default', { month: 'long', year: 'numeric' }) },
    todayStr() { return this.fmt(new Date()) },
    grid() {
      const start = new Date(this.vy, this.vm, 1).getDay(), out = []
      for (let i = 0; i < 42; i++) {
        const d = new Date(this.vy, this.vm, i - start + 1)
        out.push({ d, s: this.fmt(d), out: d.getMonth() !== this.vm, key: i })
      }
      return out
    }
  },
  methods: {
    fmt(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') },
    eventsOn(s) { return this.events.filter(e => e.date === s).slice(0, 3) },
    inSelected(s) { return this.selectable && this.selected.includes(s) },
    onCellClick(s) {
      this.$emit('datecellclick', s)
      if (!this.selectable) return
      const next = this.selected.includes(s) ? this.selected.filter(x => x !== s) : [...this.selected, s]
      this.$emit('update:selected', next)
    },
    move(n) { const m = this.vm + n; this.vy += Math.floor(m / 12); this.vm = ((m % 12) + 12) % 12; this.$emit('monthchange', this.monthLabel) },
    goToday() { const d = new Date(); this.vy = d.getFullYear(); this.vm = d.getMonth() }
  }
};
</script>

<style>
.vk-bigcal{border:1.5px solid var(--vk-line);border-radius:var(--vk-radius);background:var(--vk-surface);width:100%;overflow:hidden}
.vk-bigcal .hd{display:flex;align-items:center;justify-content:space-between;padding:13px 17px;border-bottom:1px solid var(--vk-line);font-size:15px}
.vk-bigcal .hd span{display:flex;gap:6px}
.vk-bigcal .wk{display:grid;grid-template-columns:repeat(7,1fr);background:var(--vk-sunken);font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--vk-text-3);text-align:center;padding:7px 0}
.vk-bigcal .gr{display:grid;grid-template-columns:repeat(7,1fr)}
.vk-bigcal .cell{min-height:74px;border-top:1px solid var(--vk-line);border-right:1px solid var(--vk-line);padding:6px;font-size:12px;cursor:pointer;display:flex;flex-direction:column;gap:3px}
.vk-bigcal .cell:nth-child(7n){border-right:none}
.vk-bigcal .cell:hover{background:var(--vk-sunken)}
.vk-bigcal .cell.out{color:var(--vk-text-3);background:color-mix(in srgb,var(--vk-sunken) 45%,transparent)}
.vk-bigcal .cell.today .d{background:var(--vk-grad);color:var(--vk-on-accent)}
.vk-bigcal .cell.sel{background:var(--vk-accent-soft)}
.vk-bigcal .d{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700}
.vk-bigcal .ev{color:#fff;border-radius:5px;font-size:10px;font-weight:650;padding:1.5px 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
