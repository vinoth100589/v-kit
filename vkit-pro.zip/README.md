# V-Kit Pro (63 components)

Drop-in Vue 3 components. Each .vue file is fully self-contained: no imports back into
a "v-kit" package, no build step required beyond your own Vite/Vue setup. All 4 themes
(light, dark, ocean, sunset) are bundled in every file's <style> block.

## Usage
1. Copy the .vue file(s) you need into your project's components folder.
2. Import and register normally: `import VButton from './VButton.vue'`
3. Set the theme on your root element: `document.documentElement.dataset.theme = 'dark'`

## Included components
- VAccordion
- VAdvancedColorPicker
- VAlertDialog
- VAnnouncementBar
- VAvatarGroup
- VCalendar
- VCalendarCore
- VCarousel
- VCodeBlock
- VCollapsiblePanel
- VCollapsiblePanels
- VColorButton
- VColorPicker
- VColorSelect
- VColorSplitButton
- VComboBox
- VCommandPalette
- VCountdown
- VCurrencyField
- VDateField
- VDatePicker
- VDateRangePicker
- VDateSelect
- VDatetimeField
- VDatetimePicker
- VDatetimeRangePicker
- VDatetimeSelect
- VDialog
- VDoubleSlider
- VDraggable
- VDrawer
- VEmptyState
- VFileUpload
- VGauge
- VHoverCard
- VImage
- VKbd
- VKeyboardNavigation
- VListBox
- VMenu
- VMenuButton
- VNumberField
- VOtpInput
- VPasswordField
- VPopover
- VProgressWheel
- VRating
- VResizable
- VScrollbar
- VSearchBar
- VSelectable
- VSortable
- VSplitButton
- VStat
- VSteps
- VSuggestField
- VTable
- VTimeField
- VTimeline
- VToast
- VTokenField
- VTransferList
- VTree

## Thanks for buying V-Kit Pro!
Questions or bugs? Reply to your purchase receipt email.

