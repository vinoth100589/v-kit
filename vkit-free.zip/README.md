# V-Kit Free (23 components)

Drop-in Vue 3 components. Each .vue file is fully self-contained: no imports back into
a "v-kit" package, no build step required beyond your own Vite/Vue setup. All 4 themes
(light, dark, ocean, sunset) are bundled in every file's <style> block.

## Usage
1. Copy the .vue file(s) you need into your project's components folder.
2. Import and register normally: `import VButton from './VButton.vue'`
3. Set the theme on your root element: `document.documentElement.dataset.theme = 'dark'`

## Included components
- VAlertBanner
- VAvatar
- VBadge
- VBreadcrumb
- VButton
- VButtonGroup
- VCard
- VCheckboxButton
- VChip
- VDivider
- VDropdownList
- VPagination
- VProgressBar
- VRadioButton
- VSelect
- VSkeleton
- VSlider
- VSpinner
- VTabPanel
- VTextField
- VTextarea
- VToggleSwitch
- VTooltip

## Want more?
The Pro pack adds 61 more components — full date/time suite, color pickers, data tables, command palette, and more.

