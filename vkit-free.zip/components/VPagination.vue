<template>
  <div class="vk-pgn-wrap">
    <span v-if="showTotal" class="total">{{ totalText }}</span>
    <nav class="vk-pgn" aria-label="Pagination">
      <button v-if="showFirstLast" :disabled="modelValue === 1" aria-label="First page" @click="go(1)">«</button>
      <button :disabled="modelValue === 1" aria-label="Previous page" @click="go(modelValue - 1)">‹</button>
      <template v-for="(p, i) in items" :key="i">
        <span v-if="p === '…'" class="gap">…</span>
        <button v-else :class="{ on: p === modelValue }" @click="go(p)">{{ p }}</button>
      </template>
      <button :disabled="modelValue === pages" aria-label="Next page" @click="go(modelValue + 1)">›</button>
      <button v-if="showFirstLast" :disabled="modelValue === pages" aria-label="Last page" @click="go(pages)">»</button>
    </nav>
    <select v-if="showSizeChanger" class="vk-input vk-input--sm vk-pgn-size" :value="pageSize"
      @change="$emit('update:pageSize', Number($event.target.value)); $emit('sizechange', Number($event.target.value))">
      <option v-for="s in sizeOptions" :key="s" :value="s">{{ s }} / page</option>
    </select>
    <form v-if="showJumper" class="vk-pgn-jump" @submit.prevent="jump">
      <span>Go to</span>
      <input class="vk-input vk-input--sm" type="number" min="1" :max="pages" v-model="jumpVal">
    </form>
  </div>
</template>

<script>
export default {
  name: 'VPagination',
  props: {
    modelValue: { type: Number, default: 1 },
    total: { type: Number, required: true },
    pageSize: { type: Number, default: 10 },
    showSizeChanger: Boolean,
    sizeOptions: { type: Array, default: () => [10, 20, 50, 100] },
    showTotal: Boolean,
    showFirstLast: Boolean,   // adds « / » buttons that jump straight to the first/last page
    showJumper: Boolean        // adds a "Go to page __" input
  },
  emits: ['update:modelValue', 'update:pageSize', 'change', 'sizechange'],
  data() { return { jumpVal: this.modelValue } },
  watch: { modelValue(v) { this.jumpVal = v } },
  computed: {
    pages() { return Math.max(1, Math.ceil(this.total / this.pageSize)) },
    totalText() {
      const start = (this.modelValue - 1) * this.pageSize + 1
      const end = Math.min(this.total, this.modelValue * this.pageSize)
      return start + '–' + end + ' of ' + this.total
    },
    items() {
      const p = this.modelValue, n = this.pages
      if (n <= 7) return Array.from({ length: n }, (_, i) => i + 1)
      const set = [...new Set([1, n, p - 1, p, p + 1].filter(x => x >= 1 && x <= n))].sort((a, b) => a - b)
      const out = []
      set.forEach((x, i) => { if (i && x - set[i - 1] > 1) out.push('…'); out.push(x) })
      return out
    }
  },
  methods: {
    go(p) {
      if (p < 1 || p > this.pages || p === this.modelValue) return
      this.$emit('update:modelValue', p); this.$emit('change', p)
    },
    jump() {
      const p = Math.min(this.pages, Math.max(1, Number(this.jumpVal) || 1))
      this.jumpVal = p
      this.go(p)
    }
  }
};
</script>

<style>
.vk-pgn-wrap{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
.vk-pgn-wrap .total{font-size:12px;color:var(--vk-text-3)}
.vk-pgn{display:flex;gap:5px;align-items:center}
.vk-pgn button{min-width:33px;height:33px;border:1.5px solid var(--vk-line-2);background:var(--vk-surface);border-radius:10px;cursor:pointer;font-family:inherit;font-size:12.5px;font-weight:650;color:var(--vk-text-2);padding:0 7px;transition:.14s}
.vk-pgn button:hover:not(:disabled){border-color:var(--vk-accent);color:var(--vk-accent)}
.vk-pgn button.on{background:var(--vk-grad);border-color:transparent;color:var(--vk-on-accent)}
.vk-pgn button:disabled{opacity:.4;cursor:not-allowed}
.vk-pgn .gap{color:var(--vk-text-3);padding:0 4px}
.vk-pgn-size{width:auto}
.vk-pgn-jump{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--vk-text-3)}
.vk-pgn-jump input{width:56px}

/* --- V-Kit shared styles (tokens + 4 themes + field primitives) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}


.vk-field{display:flex;flex-direction:column;gap:6px;min-width:230px;position:relative}
.vk-field > label{font-size:12.5px;font-weight:650;letter-spacing:.01em;color:var(--vk-text-2)}
.vk-field .hint{font-size:11.5px;color:var(--vk-text-3)}
.vk-field .err{font-size:11.5px;color:var(--vk-danger)}
.vk-inwrap{position:relative;display:flex;align-items:center}
.vk-input{width:100%;height:38px;padding:0 13px;border:1.5px solid var(--vk-line-2);border-radius:var(--vk-radius-s);font-family:inherit;font-size:13.5px;color:var(--vk-text);background:var(--vk-surface);outline:none;transition:.16s}
.vk-input:focus{border-color:var(--vk-accent);box-shadow:0 0 0 3.5px color-mix(in srgb,var(--vk-accent) 18%,transparent)}
.vk-input:disabled{background:var(--vk-sunken);cursor:not-allowed}
.vk-input--sm{height:31px;font-size:12.5px;padding:0 10px}
.vk-input--lg{height:45px;font-size:14.5px;padding:0 16px}
.vk-affix{position:absolute;display:flex;align-items:center;gap:2px;color:var(--vk-text-3)}
.vk-affix--r{right:8px}
.vk-affix--l{left:11px}
.vk-affix button{border:none;background:none;cursor:pointer;color:var(--vk-text-3);font-size:13px;padding:3px;border-radius:6px;display:flex;font-family:inherit}
.vk-affix button:hover{color:var(--vk-accent);background:var(--vk-accent-soft)}
.vk-spinners{display:flex;flex-direction:column}
.vk-spinners button{height:14px;line-height:1;font-size:9px;padding:0 4px}
</style>
