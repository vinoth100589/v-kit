<template>
  <transition name="vk-banner">
    <div v-if="visible" class="vk-banner" :class="['vk-banner--' + type, 'vk-banner--' + align]" role="alert">
      <span class="ic">{{ icon || { info: 'ℹ', success: '✓', warning: '⚠', error: '✕' }[type] }}</span>
      <span class="msg"><slot>{{ message }}</slot></span>
      <span v-if="actionButtons.length" class="acts">
        <button v-for="(b, i) in actionButtons" :key="i" @click="$emit('actionclick', b)">{{ b.text || b }}</button>
      </span>
      <button v-if="closeButton" class="x" aria-label="Dismiss" @click="hide">✕</button>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'VAlertBanner',
  props: {
    message: String,
    icon: String,   // override the default severity icon
    type: { type: String, default: 'info' },        // info | success | warning | error
    align: { type: String, default: 'inline' },     // inline | top | bottom (fixed)
    actionButtons: { type: Array, default: () => [] },   // [{text}] inline text actions
    closeButton: { type: Boolean, default: true },
    hideDelay: { type: Number, default: 0 }         // ms; 0 = stay
  },
  emits: ['show', 'hide', 'actionclick'],
  data() { return { visible: false } },
  methods: {
    show() {
      this.visible = true; this.$emit('show')
      if (this.hideDelay > 0) setTimeout(() => this.hide(), this.hideDelay)
    },
    hide() { this.visible = false; this.$emit('hide') }
  }
};
</script>

<style>
.vk-banner{display:flex;align-items:center;gap:11px;padding:12px 17px;border-radius:var(--vk-radius-s);font-size:13.5px;font-weight:550;border:1px solid;width:100%}
.vk-banner--top,.vk-banner--bottom{position:fixed;left:50%;transform:translateX(-50%);width:auto;min-width:340px;z-index:960;box-shadow:var(--vk-shadow-pop)}
.vk-banner--top{top:16px}
.vk-banner--bottom{bottom:16px}
.vk-banner .ic{font-weight:800}
.vk-banner .msg{flex:1}
.vk-banner .acts{display:flex;gap:10px}
.vk-banner .acts button{border:none;background:none;cursor:pointer;color:inherit;font-weight:750;text-decoration:underline;padding:0;font-size:inherit}
.vk-banner .x{border:none;background:none;cursor:pointer;color:inherit;opacity:.6;padding:2px}
.vk-banner .x:hover{opacity:1}
.vk-banner--info{background:var(--vk-info-soft);border-color:color-mix(in srgb,var(--vk-info) 30%,transparent);color:var(--vk-info)}
.vk-banner--success{background:var(--vk-success-soft);border-color:color-mix(in srgb,var(--vk-success) 30%,transparent);color:var(--vk-success)}
.vk-banner--warning{background:var(--vk-warning-soft);border-color:color-mix(in srgb,var(--vk-warning) 30%,transparent);color:var(--vk-warning)}
.vk-banner--error{background:var(--vk-danger-soft);border-color:color-mix(in srgb,var(--vk-danger) 30%,transparent);color:var(--vk-danger)}
.vk-banner-enter-active,.vk-banner-leave-active{transition:all .25s}
.vk-banner-enter-from,.vk-banner-leave-to{opacity:0;transform:translateY(-8px)}
.vk-banner--top.vk-banner-enter-from{transform:translate(-50%,-14px)}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
