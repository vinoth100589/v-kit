<template>
  <div class="vk-slider" :class="{ vert: orientation === 'vertical' }">
    <div class="track" ref="track" @mousedown="drag">
      <div class="fill" :style="fillStyle"></div>
      <div class="thumb" :style="thumbStyle" :tabindex="disabled ? -1 : 0" role="slider"
        :aria-valuenow="modelValue" :aria-valuemin="min" :aria-valuemax="max" :aria-disabled="disabled"
        :aria-orientation="orientation" @keydown="onKeydown">
        <span v-if="showTooltip" class="tip">{{ modelValue }}</span>
      </div>
      <div v-if="showTicks || marks.length" class="ticks">
        <span v-for="t in tickVals" :key="t" class="tick" :style="tickStyle(t)"></span>
      </div>
      <div v-if="marks.length" class="marklabels">
        <span v-for="m in marks" :key="m.value" class="mlabel" :style="tickStyle(m.value)">{{ m.label }}</span>
      </div>
    </div>
    <span class="minmax">{{ min }} – {{ max }}</span>
  </div>
</template>

<script>
export default {
  name: 'VSlider',
  props: {
    modelValue: { type: Number, default: 0 },
    min: { type: Number, default: 0 }, max: { type: Number, default: 100 },
    step: { type: Number, default: 1 },
    showTicks: Boolean,
    showTooltip: { type: Boolean, default: true },
    marks: { type: Array, default: () => [] },   // [{value, label}] labeled positions
    orientation: { type: String, default: 'horizontal' },
    disabled: Boolean
  },
  emits: ['update:modelValue', 'change', 'slide'],
  computed: {
    pct() { return ((this.modelValue - this.min) / (this.max - this.min)) * 100 },
    fillStyle() { return { width: this.pct + '%' } },
    thumbStyle() { return { left: this.pct + '%' } },
    tickVals() {
      if (this.marks.length) return this.marks.map(m => m.value)
      const n = Math.min(10, (this.max - this.min) / this.step)
      return Array.from({ length: n + 1 }, (_, i) => this.min + (i * (this.max - this.min)) / n)
    }
  },
  methods: {
    tickStyle(t) { return { left: ((t - this.min) / (this.max - this.min)) * 100 + '%' } },
    setFromX(clientX) {
      const r = this.$refs.track.getBoundingClientRect()
      let v = this.min + ((clientX - r.left) / r.width) * (this.max - this.min)
      v = Math.round(v / this.step) * this.step
      v = Math.min(this.max, Math.max(this.min, v))
      this.$emit('update:modelValue', v); this.$emit('slide', v)
    },
    drag(e) {
      if (this.disabled) return
      this.setFromX(e.clientX)
      const mv = (ev) => this.setFromX(ev.clientX)
      const up = () => { this.$emit('change', this.modelValue); document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up) }
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up)
    },
    nudge(d) {
      if (this.disabled) return
      const v = Math.min(this.max, Math.max(this.min, this.modelValue + d))
      this.$emit('update:modelValue', v); this.$emit('change', v)
    },
    onKeydown(e) {
      // Per the WAI-ARIA slider pattern: Right/Up increase, Left/Down decrease, regardless of orientation.
      if (this.disabled) return
      if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); this.nudge(-this.step) }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); this.nudge(this.step) }
      else if (e.key === 'PageDown') { e.preventDefault(); this.nudge(-this.step * 10) }
      else if (e.key === 'PageUp') { e.preventDefault(); this.nudge(this.step * 10) }
      else if (e.key === 'Home') { e.preventDefault(); this.$emit('update:modelValue', this.min); this.$emit('change', this.min) }
      else if (e.key === 'End') { e.preventDefault(); this.$emit('update:modelValue', this.max); this.$emit('change', this.max) }
    }
  }
};
</script>

<style>
.vk-slider{display:flex;align-items:center;gap:14px;min-width:260px;padding:14px 0}
.vk-slider .track{position:relative;flex:1;height:7px;border-radius:999px;background:var(--vk-sunken);cursor:pointer}
.vk-slider .fill{position:absolute;top:0;bottom:0;left:0;border-radius:999px;background:var(--vk-grad)}
.vk-slider .thumb{position:absolute;top:50%;transform:translate(-50%,-50%);width:19px;height:19px;border-radius:50%;background:var(--vk-surface);border:2.5px solid var(--vk-accent);box-shadow:var(--vk-shadow);cursor:grab}
.vk-slider .thumb:active{cursor:grabbing}
.vk-slider .tip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);background:var(--vk-shell);color:#fff;border-radius:6px;font-size:11px;padding:2px 8px;white-space:nowrap}
.vk-slider .ticks{position:absolute;top:100%;left:0;right:0;height:8px}
.vk-slider .tick{position:absolute;top:4px;width:1.5px;height:5px;background:var(--vk-line-2);transform:translateX(-50%)}
.vk-slider .marklabels{position:absolute;top:calc(100% + 11px);left:0;right:0;height:14px}
.vk-slider .mlabel{position:absolute;transform:translateX(-50%);font-size:10.5px;color:var(--vk-text-3);white-space:nowrap}
.vk-slider .minmax{font-size:11.5px;color:var(--vk-text-3);white-space:nowrap}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
