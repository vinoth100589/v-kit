<template>
  <div class="vk-pbar" :class="'vk-pbar--' + size" role="progressbar" :aria-valuenow="mode === 'determinate' ? value : null">
    <div class="row">
      <span v-if="statusMessage" class="msg">{{ statusMessage }}</span>
      <span v-if="mode === 'determinate'" class="val">{{ value }}%</span>
    </div>
    <div class="track">
      <div v-if="bufferValue !== null && mode === 'determinate'" class="buffer" :style="{ width: bufferValue + '%' }"></div>
      <div v-if="mode === 'determinate'" class="fill" :class="{ striped, animated }" :style="{ width: value + '%', background: progressColor || '' }"></div>
      <div v-else class="fill indet"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'VProgressBar',
  props: {
    value: { type: Number, default: 0 },
    mode: { type: String, default: 'determinate' },   // determinate | indeterminate
    size: { type: String, default: 'medium' },         // thin | medium | thick
    statusMessage: String,
    progressColor: String,
    striped: Boolean,     // diagonal stripe texture on the fill
    animated: Boolean,    // animates the stripes
    bufferValue: { type: Number, default: null }   // secondary lighter fill (e.g. "buffered" amount), 0-100
  },
  emits: ['complete'],
  watch: { value(v) { if (v >= 100) this.$emit('complete') } }
};
</script>

<style>
.vk-pbar{width:100%;min-width:260px}
.vk-pbar .row{display:flex;justify-content:space-between;margin-bottom:7px;font-size:12px}
.vk-pbar .msg{color:var(--vk-text-2);font-weight:600}
.vk-pbar .val{color:var(--vk-text-3);font-weight:700;font-family:var(--vk-mono)}
.vk-pbar .track{height:9px;border-radius:999px;background:var(--vk-sunken);overflow:hidden;position:relative}
.vk-pbar .buffer{position:absolute;top:0;left:0;height:100%;border-radius:999px;background:var(--vk-accent-soft);transition:width .35s}
.vk-pbar--thin .track{height:5px}
.vk-pbar--thick .track{height:14px}
.vk-pbar .fill{height:100%;border-radius:999px;background:var(--vk-grad);transition:width .35s}
.vk-pbar .fill.striped{background-image:linear-gradient(45deg,rgba(255,255,255,.22) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.22) 50%,rgba(255,255,255,.22) 75%,transparent 75%,transparent);background-size:16px 16px}
.vk-pbar .fill.striped.animated{animation:vk-pbar-stripe 1s linear infinite}
@keyframes vk-pbar-stripe{from{background-position:0 0}to{background-position:16px 0}}
.vk-pbar .fill.indet{width:36%;animation:vk-indet 1.15s ease-in-out infinite}
@keyframes vk-indet{0%{margin-left:-36%}100%{margin-left:100%}}

/* --- V-Kit shared styles (tokens + 4 themes) — bundled so this file is drop-in --- */
:root, [data-theme=light]{
  --vk-accent:#7c3aed; --vk-accent-2:#06b6d4; --vk-accent-hover:#6d28d9;
  --vk-accent-soft:#f3eefe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#7c3aed,#06b6d4);
  --vk-danger:#e11d48; --vk-danger-soft:#fff1f2;
  --vk-success:#059669; --vk-success-soft:#ecfdf5;
  --vk-warning:#d97706; --vk-warning-soft:#fffbeb;
  --vk-info:#0284c7; --vk-info-soft:#f0f9ff;
  --vk-bg:#f6f7fb; --vk-surface:#ffffff; --vk-sunken:#eef0f6; --vk-raised:#ffffff;
  --vk-text:#16182d; --vk-text-2:#5b5f7b; --vk-text-3:#9598b0;
  --vk-line:#e4e6f0; --vk-line-2:#cdd1e0;
  --vk-radius:14px; --vk-radius-s:9px; --vk-radius-xs:7px;
  --vk-shadow:0 1px 2px rgba(22,24,45,.06),0 4px 14px rgba(22,24,45,.06);
  --vk-shadow-pop:0 12px 40px rgba(22,24,45,.18);
  --vk-font:"Avenir Next","Segoe UI Variable","Segoe UI",system-ui,-apple-system,sans-serif;
  --vk-mono:"Cascadia Code",ui-monospace,SFMono-Regular,Menlo,monospace;
  --vk-shell:#0b1020; --vk-shell-2:#141a30; --vk-shell-text:#aab1d6; --vk-shell-line:#232b4a;
}
[data-theme=dark]{
  --vk-accent:#a78bfa; --vk-accent-2:#22d3ee; --vk-accent-hover:#c4b5fd;
  --vk-accent-soft:#2b2350; --vk-on-accent:#16182d;
  --vk-grad:linear-gradient(135deg,#8b5cf6,#0ea5e9);
  --vk-danger:#fb7185; --vk-danger-soft:#3d1a24;
  --vk-success:#34d399; --vk-success-soft:#122e24;
  --vk-warning:#fbbf24; --vk-warning-soft:#33270e;
  --vk-info:#38bdf8; --vk-info-soft:#0e2a3a;
  --vk-bg:#0e1122; --vk-surface:#181c33; --vk-sunken:#111428; --vk-raised:#1f2440;
  --vk-text:#e7e9f7; --vk-text-2:#a6abcc; --vk-text-3:#6d7396;
  --vk-line:#282e4e; --vk-line-2:#3a4166;
  --vk-shadow:0 1px 2px rgba(0,0,0,.4),0 4px 14px rgba(0,0,0,.35);
  --vk-shadow-pop:0 12px 44px rgba(0,0,0,.6);
  --vk-shell:#070a16; --vk-shell-2:#0e1226; --vk-shell-text:#8f96bd; --vk-shell-line:#1c2340;
}
[data-theme=ocean]{
  --vk-accent:#0369a1; --vk-accent-2:#0d9488; --vk-accent-hover:#075985;
  --vk-accent-soft:#e0f2fe; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#0369a1,#0d9488);
  --vk-bg:#f0f7fa; --vk-surface:#ffffff; --vk-sunken:#e2eef4; --vk-raised:#ffffff;
  --vk-text:#0c2433; --vk-text-2:#48657a; --vk-text-3:#8aa2b3;
  --vk-line:#d6e5ed; --vk-line-2:#b7cedc;
  --vk-shell:#062033; --vk-shell-2:#0a2c45; --vk-shell-text:#93b8cf; --vk-shell-line:#123c5a;
}
[data-theme=sunset]{
  --vk-accent:#ea580c; --vk-accent-2:#db2777; --vk-accent-hover:#c2410c;
  --vk-accent-soft:#ffedd5; --vk-on-accent:#ffffff;
  --vk-grad:linear-gradient(135deg,#ea580c,#db2777);
  --vk-bg:#fdf7f2; --vk-surface:#ffffff; --vk-sunken:#f7ece2; --vk-raised:#ffffff;
  --vk-text:#331d10; --vk-text-2:#7a5b48; --vk-text-3:#b1988a;
  --vk-line:#f0e0d2; --vk-line-2:#e0c8b4;
  --vk-shell:#2a130b; --vk-shell-2:#3b1c10; --vk-shell-text:#d3a892; --vk-shell-line:#57291a;
}

</style>
